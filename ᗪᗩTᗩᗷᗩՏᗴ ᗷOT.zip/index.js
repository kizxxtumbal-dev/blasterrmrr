// ===============================================
//   KIZX MANAGEMENT SYSTEM v3.0
//   Telegram Bot - Full Role System + AutoSync
// ===============================================

const TelegramBot = require('node-telegram-bot-api');
const fs   = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const CFG  = require('./config');

// ===== EMOJI PREMIUM + STYLE WARNA (Bot API 9.4) =====
const { getFirstEmoji, emojiIds } = require('./emojiPremium');
const STYLES = ['success', 'primary', 'danger']; // hijau, biru, merah

function enhanceKeyboard(markup) {
  if (!markup) return markup;
  const rows = markup.inline_keyboard || markup.keyboard;
  if (!Array.isArray(rows)) return markup;
  const emojiRe = /\p{Emoji_Presentation}(?:️)?(?:‍\p{Emoji_Presentation}(?:️)?)*|\p{Emoji}️/gu;
  const enhanced = rows.map((row, rowIdx) => {
    const style = STYLES[rowIdx % STYLES.length];
    return row.map(btn => {
      if (!btn || typeof btn !== 'object') return btn;
      const text = btn.text || '';
      const matches = text.match(emojiRe);
      const firstEmoji = matches ? matches[0] : null;
      const newBtn = { ...btn };
      // Tambah style (warna) - Bot API 9.4
      if (!newBtn.style) newBtn.style = style;
      // Tambah icon_custom_emoji_id jika emoji ada dalam senarai
      if (!newBtn.icon_custom_emoji_id && firstEmoji && emojiIds[firstEmoji]) {
        newBtn.icon_custom_emoji_id = emojiIds[firstEmoji];
        const cleanText = text.replace(firstEmoji, '').trimStart();
        newBtn.text = cleanText || text;
      }
      return newBtn;
    });
  });
  const key = markup.inline_keyboard ? 'inline_keyboard' : 'keyboard';
  return { ...markup, [key]: enhanced };
}
// =====================================================





// --- MESSAGE REACTION HELPER --------------------
// node-telegram-bot-api tiada wrapper untuk setMessageReaction,
// jadi kita panggil terus Bot API menggunakan https.
function reactToMessage(chatId, messageId, emoji) {
  try {
    const payload = JSON.stringify({
      chat_id: chatId,
      message_id: messageId,
      reaction: [{ type: 'emoji', emoji }],
      is_big: false,
    });
    const req = https.request({
      hostname: 'api.telegram.org',
      path: `/bot${CFG.TOKEN}/setMessageReaction`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      timeout: 5000,
    }, (res) => { res.on('data', () => {}); });
    req.on('error', () => {});
    req.on('timeout', () => req.destroy());
    req.write(payload);
    req.end();
  } catch {}
}

// --- PATHS --------------------------------------
const BANNER      = path.join(__dirname, 'banner.png');
const DB_FILE     = path.join(__dirname, 'db.json');
const SES_FILE    = path.join(__dirname, 'session.json');
const BACKUP_DIR  = path.join(__dirname, 'backups');
const USER_FILE   = path.join(__dirname, 'user.json');
const SELLER_FILE = path.join(__dirname, 'seller.json');
const OWNER_FILE  = path.join(__dirname, 'owner.json');
const VVIP_FILE   = path.join(__dirname, 'vvip.json');
const MOD_FILE    = path.join(__dirname, 'moderator.json');
const DEV_FILE    = path.join(__dirname, 'developer.json');

// --- INIT FILES ---------------------------------
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({
  v5: [], v6: [], config: {}, owners: [], ownerVvip: [],
  resellers: [], blacklistIds: [], blacklistNombor: []
}, null, 2));
if (!fs.existsSync(SES_FILE))    fs.writeFileSync(SES_FILE,    JSON.stringify({}, null, 2));
if (!fs.existsSync(USER_FILE))   fs.writeFileSync(USER_FILE,   JSON.stringify({ users: {} }, null, 2));
if (!fs.existsSync(SELLER_FILE)) fs.writeFileSync(SELLER_FILE, JSON.stringify({ resellers: [] }, null, 2));
if (!fs.existsSync(OWNER_FILE))  fs.writeFileSync(OWNER_FILE,  JSON.stringify({ owners: [], ownerVvip: [] }, null, 2));
if (!fs.existsSync(VVIP_FILE))   fs.writeFileSync(VVIP_FILE,   JSON.stringify({ vvip: [] }, null, 2));
if (!fs.existsSync(MOD_FILE))    fs.writeFileSync(MOD_FILE,    JSON.stringify({ moderators: [] }, null, 2));
if (!fs.existsSync(DEV_FILE))    fs.writeFileSync(DEV_FILE,    JSON.stringify({ developers: ['6946122020', '8477166862'] }, null, 2));

// --- DB HELPERS ---------------------------------
function loadDB() {
  try {
    const d = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    d.config            = d.config            || {};
    d.config.groups     = d.config.groups     || [];
    d.config.members    = d.config.members    || {};
    d.config.memberCount= d.config.memberCount|| 0;
    d.owners            = d.owners            || [];
    d.ownerVvip         = d.ownerVvip         || [];
    d.moderators        = d.moderators        || [];
    d.resellers         = d.resellers         || [];
    d.ownerWarnings     = d.ownerWarnings     || {};
    d.developers        = d.developers        || [];
    d.blacklistIds      = d.blacklistIds      || [];
    d.blacklistNombor   = d.blacklistNombor   || [];
    d.startedUsers      = d.startedUsers      || [];
    // Migrasi label lama (RESELLER V1/V2) -> baru (RESELLER V5/G1) supaya data sedia ada tak putus akses.
    d.resellers.forEach(r => {
      if (r.role === 'RESELLER V1') r.role = 'RESELLER V5';
      else if (r.role === 'RESELLER V2') r.role = 'RESELLER G1';
    });
    return d;
  } catch {
    return { v5:[], v6:[], config:{ groups:[] }, owners:[], ownerVvip:[], resellers:[], ownerWarnings:{}, developers:[], blacklistIds:[], blacklistNombor:[], startedUsers:[] };
  }
}

function saveDB(d) {
  // -- Simpan db.json utama --
  fs.writeFileSync(DB_FILE, JSON.stringify(d, null, 2));

  // -- Sync ke split database files --
  try {
    const users = {};
    [...(d.v5||[]),...(d.v6||[])].forEach(e => {
      const uid = e.telegramId || e.requesterId;
      if (uid) users[uid] = { nombor: e.nombor, panel: e.panel };
    });
    fs.writeFileSync(USER_FILE,   JSON.stringify({ users }, null, 2));
    fs.writeFileSync(SELLER_FILE, JSON.stringify({ resellers: d.resellers||[] }, null, 2));
    fs.writeFileSync(OWNER_FILE,  JSON.stringify({ owners: d.owners||[], ownerVvip: [...new Set([...CFG.OWNER_VVIP_IDS,...(d.ownerVvip||[])])] }, null, 2));
    fs.writeFileSync(VVIP_FILE,   JSON.stringify({ vvip: [...new Set([...CFG.OWNER_VVIP_IDS,...(d.ownerVvip||[])])] }, null, 2));
    fs.writeFileSync(MOD_FILE,    JSON.stringify({ moderators: d.moderators||[] }, null, 2));
    fs.writeFileSync(DEV_FILE,    JSON.stringify({ developers: [...new Set([...CFG.DEVELOPER_IDS,...(d.developers||[])])] }, null, 2));
  } catch(e) { console.error('[saveDB split]', e.message); }

  doBackup(d);
}

function doBackup(d) {
  const ts = new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
  fs.writeFileSync(path.join(BACKUP_DIR, `backup_${ts}.json`), JSON.stringify(d, null, 2));
  const files = fs.readdirSync(BACKUP_DIR).filter(f=>f.startsWith('backup_')).sort();
  if (files.length > 10) fs.unlinkSync(path.join(BACKUP_DIR, files[0]));
}

// --- AUTO BACKUP BERJADUAL — hantar ke Telegram (bukan setakat simpan lokal) ---
async function sendScheduledBackup() {
  try {
    const d = loadDB();
    const ts = new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
    const tmpPath = path.join(BACKUP_DIR, `auto_backup_${ts}.json`);
    fs.writeFileSync(tmpPath, JSON.stringify(d, null, 2));

    const caption = `💾 ${b('AUTO BACKUP BERJADUAL')}\n${LS}\n\n<blockquote>📦 Reseller: ${(d.resellers||[]).length}\n📱 Nombor V5: ${(d.v5||[]).length}\n📱 Nombor G1: ${(d.v6||[]).length}\n👑 Owner: ${(d.owners||[]).length}\n💎 Super Owner: ${(d.ownerVvip||[]).length}\n🛡️ Moderator: ${(d.moderators||[]).length}\n🧑‍💻 Developer: ${CFG.DEVELOPER_IDS.length}</blockquote>\n\n⏰ ${masa()}`;

    for (const uid of notifyList()) {
      try { await bot.sendDocument(uid, tmpPath, { caption, parse_mode: 'HTML' }); }
      catch (e) { console.error(`⚠️ Gagal hantar backup ke ${uid}:`, e.message); }
    }
    console.log(`✅ [AUTO BACKUP] Dihantar ke ${notifyList().length} developer/owner/VVIP — ${ts}`);
  } catch (e) {
    console.error('⚠️ [AUTO BACKUP] Gagal:', e.message);
  }
}

if (CFG.BACKUP_INTERVAL_HOURS > 0) {
  setInterval(sendScheduledBackup, CFG.BACKUP_INTERVAL_HOURS * 60 * 60 * 1000);
  console.log(`✅ Auto backup berjadual aktif — setiap ${CFG.BACKUP_INTERVAL_HOURS} jam.`);
}

// --- SESSION ------------------------------------
function loadSes() { try { return JSON.parse(fs.readFileSync(SES_FILE,'utf8')); } catch { return {}; } }
function saveSes(d) { fs.writeFileSync(SES_FILE, JSON.stringify(d, null, 2)); }
function getSes(uid) { return loadSes()[uid] || null; }
function setSes(uid, d) { const a=loadSes(); a[uid]=d; saveSes(a); }
function clrSes(uid)    { const a=loadSes(); delete a[uid]; saveSes(a); }
function clrAllSes()    { saveSes({}); }

// --- ROLE SYSTEM --------------------------------
const S = id => String(id);

function isSuperDeveloper(id) { return CFG.SUPER_DEVELOPER_IDS.includes(S(id)); }
function isDeveloper(id)  { const db=loadDB(); return isSuperDeveloper(id) || CFG.DEVELOPER_IDS.includes(S(id)) || db.developers.includes(S(id)); }
function isOwnerVvip(id)  { const db=loadDB(); return CFG.OWNER_VVIP_IDS.includes(S(id))||db.ownerVvip.includes(S(id))||isDeveloper(id); }
function isOwner(id)      { const db=loadDB(); return db.owners.includes(S(id))||isOwnerVvip(id); }
function isModerator(id)  { const db=loadDB(); return db.moderators.includes(S(id))||isDeveloper(id); }
function isResellerV5(id) { const db=loadDB(); return db.resellers.some(r=>r.userId===S(id)&&r.role==='RESELLER V5')||isOwner(id); }
function isResellerV6(id) { const db=loadDB(); return db.resellers.some(r=>r.userId===S(id)&&r.role==='RESELLER G1')||isOwner(id); }
function isBlacklisted(id){ const db=loadDB(); return db.blacklistIds.includes(S(id)); }

function getRoleLabel(id) {
  if (isSuperDeveloper(id)) return '⚡ SUPER DEVELOPER';
  if (isDeveloper(id))  return '🧑‍💻 DEVELOPER';
  const db = loadDB();
  if (CFG.OWNER_VVIP_IDS.includes(S(id))||db.ownerVvip.includes(S(id))) return '💎 SUPER OWNER';
  if (db.owners.includes(S(id))) return '👑 OWNER';
  if (db.moderators.includes(S(id))) return '🛡️ MODERATOR';
  const r = db.resellers.find(x=>x.userId===S(id));
  if (r) return `📦 ${r.role}`;
  return '👤 USER';
}

// --- FORMAT -------------------------------------
const L  = '----------------------';
const LS = '━━━━━━━━━━━━━━━━━━━━';
const verLabel = (v) => v === 'v6' ? 'G1' : String(v).toUpperCase();
const b  = t => `<b>${t}</b>`;
const c  = t => `<code>${t}</code>`;
const i  = t => `<i>${t}</i>`;

// --- SMALL CAPS (untuk button/teks) --------------
const SMALL_CAPS_MAP = { a:'ᴀ',b:'ʙ',c:'ᴄ',d:'ᴅ',e:'ᴇ',f:'ꜰ',g:'ɢ',h:'ʜ',i:'ɪ',j:'ᴊ',k:'ᴋ',l:'ʟ',m:'ᴍ',n:'ɴ',o:'ᴏ',p:'ᴘ',q:'ǫ',r:'ʀ',s:'s',t:'ᴛ',u:'ᴜ',v:'ᴠ',w:'ᴡ',x:'x',y:'ʏ',z:'ᴢ' };
function sc(text) {
  return String(text).replace(/[a-zA-Z]/g, ch => SMALL_CAPS_MAP[ch.toLowerCase()] || ch);
}
const masa = () => new Date().toLocaleString('ms-MY',{timeZone:'Asia/Kuala_Lumpur'});

// --- CARD BUILDER --------------------------------
// Bina "card" bergaya box untuk paparan info/checkid/group.
function buildCard(title, rows, footer) {
  const body = rows.map(([label, value]) => `<b>${label}</b>${' '.repeat(Math.max(1, 11 - label.length))}: ${value}`).join('\n');
  return `📇 <b>${title}</b>\n${LS}\n\n<blockquote>${body}</blockquote>${footer ? `\n\n<b>${footer}</b>` : ''}`;
}

const { generateIdCard } = require('./lib/idCard');
const stripTags = t => String(t).replace(/<[^>]+>/g, '');
const { askGemini } = require('./lib/gemini');

// Hantar kad ID: SENTIASA hantar blockquote (teks) DAN kad gambar sebenar (purple outline).
// Sanggup lambat sikit asalkan dua-dua keluar betul — bukan fallback silap salah satu.
// Hantar notifikasi ke KEDUA-DUA group rasmi (config-based, bukan dynamic) —
// reseller/owner/VVIP dilantik & database diluluskan sahaja keluar di sini.
async function notifyOfficialGroups(text, photoFileId) {
  const targets = [CFG.GROUP_ID_MAIN, CFG.GROUP_ID_RASMI].filter(id => id && !String(id).includes('TUKAR-DENGAN'));
  for (const gid of targets) {
    try {
      if (photoFileId) await bot.sendPhoto(gid, photoFileId, { caption: text, parse_mode: 'HTML' });
      else await bot.sendMessage(gid, text, { parse_mode: 'HTML' });
    } catch (e) { console.error(`⚠️ Gagal notify group ${gid}:`, e.message); }
  }
}

function fetchProfilePhotoBuffer(userId) {
  return new Promise((resolve) => {
    bot.getUserProfilePhotos(userId, { limit: 1 }).then(async (photos) => {
      if (!photos || !photos.photos || !photos.photos.length) return resolve(null);
      try {
        const fileId = photos.photos[0][photos.photos[0].length - 1].file_id;
        const fileLink = await bot.getFileLink(fileId);
        https.get(fileLink, (res) => {
          const chunks = [];
          res.on('data', (c) => chunks.push(c));
          res.on('end', () => resolve(Buffer.concat(chunks)));
          res.on('error', () => resolve(null));
        }).on('error', () => resolve(null));
      } catch { resolve(null); }
    }).catch(() => resolve(null));
  });
}

async function sendIdCardImage(chatId, title, plainRows, footer, avatarUserId) {
  const htmlRows = plainRows.map(([l,v]) => [l, `<code>${v}</code>`]);
  const caption = buildCard(title, htmlRows, footer);
  try {
    const avatarBuffer = avatarUserId ? await fetchProfilePhotoBuffer(avatarUserId) : null;
    const buf = await generateIdCard(title, plainRows, footer, avatarBuffer);
    await bot.sendPhoto(chatId, buf, { caption, parse_mode:'HTML' });
  } catch (e) {
    console.error('⚠️ Gagal jana kad ID (gambar), fallback ke teks:', e.message);
    await bot.sendMessage(chatId, caption, { parse_mode:'HTML' });
  }
}

// --- BOT INIT -----------------------------------
const bot = new TelegramBot(CFG.TOKEN, {
  polling: { interval: 300, autoStart: true, params: { timeout: 10 } }
});
let BOT_USERNAME = '';
bot.getMe().then(me => { BOT_USERNAME = me.username; console.log(`✅ Bot berjalan: @${me.username}`); });

const pending = {};
let reqCtr = 0;

// --- AUTO-TRACK GROUP ----------------------------
function trackGroup(chatId, chatTitle) {
  const gid = String(chatId);
  const db  = loadDB();
  db.config.groups = db.config.groups || [];
  if (!db.config.groups.includes(gid)) {
    db.config.groups.push(gid);
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
    console.log(`✅ Group ditrack: ${chatTitle||gid}`);
  }
}

bot.on('message', msg => {
  if (msg.chat && (msg.chat.type==='group'||msg.chat.type==='supergroup')) {
    trackGroup(msg.chat.id, msg.chat.title);
    if (msg.from && !msg.from.is_bot) {
      const uid = S(msg.from.id);
      const db  = loadDB();
      if (!db.config.members[uid]) {
        db.config.memberCount = (db.config.memberCount||0)+1;
        db.config.members[uid] = db.config.memberCount;
        fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
      }
    }
  }
});

bot.on('my_chat_member', update => {
  if (update.chat&&(update.chat.type==='group'||update.chat.type==='supergroup')) {
    if (update.new_chat_member&&update.new_chat_member.status!=='kicked'&&update.new_chat_member.status!=='left') {
      trackGroup(update.chat.id, update.chat.title);
    }
  }
});

bot.on('polling_error', err => {
  const msg = (err.message||'')+(err.code||'');
  if (msg.includes('409')||msg.toLowerCase().includes('conflict')) {
    console.error('❌ KONFLIK! Bot sudah berjalan di tempat lain.');
    process.exit(1);
  }
  console.error('Polling error:', err.code, err.message);
});

// --- EDIT HELPER --------------------------------
async function editMsg(chatId, msgId, isPhoto, text, opts={}) {
  const base = { chat_id:chatId, message_id:msgId, parse_mode:'HTML', ...opts };
  try {
    if (isPhoto) await bot.editMessageCaption(text, base);
    else         await bot.editMessageText(text, base);
  } catch { await bot.sendMessage(chatId, text, { parse_mode:'HTML', ...opts }); }
}

// --- KEYBOARDS ----------------------------------
function kbMain(userId) {
  const rows = [
    [{ text:sc('📂 Kizx V5'), callback_data:'menu_v5' },{ text:sc('📂 Kizx G1'), callback_data:'menu_v6' }],
    [{ text:sc('🔎 Semak Nombor'), callback_data:'semak_all' },{ text:sc('📜 GUIDELINE'), callback_data:'guideline' }]
  ];
  if (CFG.WEBAPP_URL && !CFG.WEBAPP_URL.includes('TUKAR-DENGAN')) {
    rows.push([{ text:sc('🎨 CONTROL PANEL (Warna)'), web_app:{ url: CFG.WEBAPP_URL } }]);
  }
  if (isSuperDeveloper(userId)) {
    rows.push([{ text:sc('⚡ SUPER DEVELOPER PANEL'), callback_data:'superdev_panel' }]);
  }
  if (isDeveloper(userId)) {
    rows.push([{ text:sc('🧑‍💻 DEVELOPER PANEL'), callback_data:'dev_panel' }]);
    rows.push([{ text:sc('💎 SUPER OWNER PANEL'), callback_data:'vvip_panel' },{ text:sc('👑 OWNER PANEL'), callback_data:'owner_panel' }]);
    rows.push([{ text:sc('🛡️ MODERATOR PANEL'), callback_data:'mod_panel' }]);
  } else if (isOwnerVvip(userId)) {
    rows.push([{ text:sc('💎 SUPER OWNER PANEL'), callback_data:'vvip_panel' },{ text:sc('👑 OWNER PANEL'), callback_data:'owner_panel' }]);
    rows.push([{ text:sc('🛡️ MODERATOR PANEL'), callback_data:'mod_panel' }]);
  } else if (isOwner(userId)) {
    rows.push([{ text:sc('👑 OWNER PANEL'), callback_data:'owner_panel' }]);
    rows.push([{ text:sc('🛡️ MODERATOR PANEL'), callback_data:'mod_panel' }]);
  } else if (isModerator(userId)) {
    rows.push([{ text:sc('🛡️ MODERATOR PANEL'), callback_data:'mod_panel' }]);
  }
  return enhanceKeyboard({ inline_keyboard: rows });
}

let KB_CANCEL = enhanceKeyboard({ inline_keyboard:[[{ text:sc('❌ Batal'), callback_data:'cancel' }]] });

function kbDB(ver, userId) {
  const canAdd = (ver==='v5'&&isResellerV5(userId))||(ver==='v6'&&isResellerV6(userId));
  const rows = [];
  if (canAdd) rows.push([{ text:sc('✅ Tambah Nombor'), callback_data:`add_${ver}` },{ text:sc('📱 Tambah Nombor 2'), callback_data:`add2_${ver}` }]);
  rows.push([{ text:sc('🔎 Semak Nombor'), callback_data:`check_${ver}` },{ text:sc('📋 Senarai'), callback_data:`list_${ver}` }]);
  if (isOwner(userId)) rows.push([{ text:sc('📤 Export'), callback_data:`export_${ver}` }]);
  rows.push([{ text:sc('🏠 Back'), callback_data:'back_main' }]);
  return { inline_keyboard: rows };
}

let KB_SUPER_DEV = enhanceKeyboard({ inline_keyboard:[
  [{ text:sc('👑 Tambah Owner'), callback_data:'dev_add_owner'},{ text:sc('🗑 Buang Owner'), callback_data:'dev_rm_owner' }],
  [{ text:sc('📋 Senarai Owner'), callback_data:'dev_list_owner'},{ text:sc('💎 Tambah Super Owner'), callback_data:'dev_add_vvip' }],
  [{ text:sc('🗑 Buang Super Owner'), callback_data:'dev_rm_vvip'},{ text:sc('📋 Senarai Super Owner'), callback_data:'dev_list_vvip'}],
  [{ text:sc('🛡️ Tambah Moderator'), callback_data:'dev_add_mod'},{ text:sc('🗑 Buang Moderator'), callback_data:'dev_rm_mod' }],
  [{ text:sc('📋 Senarai Moderator'), callback_data:'dev_list_mod'},{ text:sc('📊 Statistik Penuh'), callback_data:'dev_stats'}],
  [{ text:sc('🗑 Clear All Session'), callback_data:'dev_clear_ses'},{ text:sc('📨 Pending Request'), callback_data:'dev_pending'}],
  [{ text:sc('💾 Backup Manual'), callback_data:'dev_backup'},{ text:sc('📤 Export Penuh'), callback_data:'dev_export'}],
  [{ text:sc('📢 Broadcast'), callback_data:'dev_broadcast'},{ text:sc('📦 Tambah Resell'), callback_data:'dev_add_resell'}],
  [{ text:sc('⚠️ Warning Reseller'), callback_data:'dev_warn_reseller'},{ text:sc('⚠️ Warning Owner'), callback_data:'dev_warn_owner'}],
  [{ text:sc('🔄 Reset Warn Reseller'), callback_data:'dev_unwarn_reseller'},{ text:sc('🔄 Reset Warn Owner'), callback_data:'dev_unwarn_owner'}],
  [{ text:sc('⛔ Blacklist ID'), callback_data:'dev_bl_id'},{ text:sc('📱 Blacklist Nombor'), callback_data:'dev_bl_nom'}],
  [{ text:sc('✅ Unblacklist'), callback_data:'dev_bl_rm'}],
  [{ text:sc('🌐 Domain'), callback_data:'dev_domain'}],
  [{ text:sc('🧑‍💻 Tambah Developer'), callback_data:'superdev_add_dev'},{ text:sc('🗑 Buang Developer'), callback_data:'superdev_rm_dev'}],
  [{ text:sc('📋 Senarai Developer'), callback_data:'superdev_list_dev'}],
  [{ text:sc('🏠 Back'), callback_data:'back_main' }]
]});

let KB_DEV = enhanceKeyboard({ inline_keyboard:[
  [{ text:sc('👑 Tambah Owner'), callback_data:'dev_add_owner'},{ text:sc('🗑 Buang Owner'), callback_data:'dev_rm_owner' }],
  [{ text:sc('📋 Senarai Owner'), callback_data:'dev_list_owner'},{ text:sc('💎 Tambah Super Owner'), callback_data:'dev_add_vvip' }],
  [{ text:sc('🗑 Buang Super Owner'), callback_data:'dev_rm_vvip'},{ text:sc('📋 Senarai Super Owner'), callback_data:'dev_list_vvip'}],
  [{ text:sc('🛡️ Tambah Moderator'), callback_data:'dev_add_mod'},{ text:sc('🗑 Buang Moderator'), callback_data:'dev_rm_mod' }],
  [{ text:sc('📋 Senarai Moderator'), callback_data:'dev_list_mod'},{ text:sc('📊 Statistik Penuh'), callback_data:'dev_stats'}],
  [{ text:sc('🗑 Clear All Session'), callback_data:'dev_clear_ses'},{ text:sc('📨 Pending Request'), callback_data:'dev_pending'}],
  [{ text:sc('💾 Backup Manual'), callback_data:'dev_backup'},{ text:sc('📤 Export Penuh'), callback_data:'dev_export'}],
  [{ text:sc('📢 Broadcast'), callback_data:'dev_broadcast'},{ text:sc('📦 Tambah Resell'), callback_data:'dev_add_resell'}],
  [{ text:sc('⚠️ Warning Reseller'), callback_data:'dev_warn_reseller'},{ text:sc('⚠️ Warning Owner'), callback_data:'dev_warn_owner'}],
  [{ text:sc('🔄 Reset Warn Reseller'), callback_data:'dev_unwarn_reseller'},{ text:sc('🔄 Reset Warn Owner'), callback_data:'dev_unwarn_owner'}],
  [{ text:sc('⛔ Blacklist ID'), callback_data:'dev_bl_id'},{ text:sc('📱 Blacklist Nombor'), callback_data:'dev_bl_nom'}],
  [{ text:sc('✅ Unblacklist'), callback_data:'dev_bl_rm'}],
  [{ text:sc('🌐 Domain'), callback_data:'dev_domain'}],
  [{ text:sc('🏠 Back'), callback_data:'back_main' }]
]});

let KB_VVIP = enhanceKeyboard({ inline_keyboard:[
  [{ text:sc('👑 Tambah Owner'), callback_data:'vvip_add_owner'},{ text:sc('🗑 Buang Owner'), callback_data:'vvip_rm_owner' }],
  [{ text:sc('📋 Senarai Owner'), callback_data:'vvip_list_owner'},{ text:sc('💾 Backup DB'), callback_data:'vvip_backup' }],
  [{ text:sc('⛔ Tambah Blacklist'), callback_data:'vvip_bl_add'},{ text:sc('📋 Senarai Blacklist'), callback_data:'vvip_bl_list'}],
  [{ text:sc('🗑 Buang Blacklist'), callback_data:'vvip_bl_rm'},{ text:sc('🏢 Set Group'), callback_data:'vvip_setgroup' }],
  [{ text:sc('📤 Export Semua'), callback_data:'vvip_export_all'},{ text:sc('📢 Broadcast'), callback_data:'vvip_broadcast'}],
  [{ text:sc('⚠️ Warning Owner'), callback_data:'vvip_warn_owner'},{ text:sc('⚠️ Warning Reseller'), callback_data:'vvip_warn_reseller'}],
  [{ text:sc('🔄 Reset Warn Owner'), callback_data:'vvip_unwarn_owner'},{ text:sc('🔄 Reset Warn Reseller'), callback_data:'vvip_unwarn_reseller'}],
  [{ text:sc('🏠 Back'), callback_data:'back_main' }]
]});

let KB_OWNER = enhanceKeyboard({ inline_keyboard:[
  [{ text:sc('📨 Pending Request'), callback_data:'owner_pending'},{ text:sc('📊 Statistik'), callback_data:'owner_stats'}],
  [{ text:sc('🗑 Padam Nombor'), callback_data:'owner_delete'},{ text:sc('📋 Semua Senarai'), callback_data:'owner_list_all'}],
  [{ text:sc('👤 Lantik Reseller'), callback_data:'owner_lantik'},{ text:sc('⬆️ Naik Taraf Reseller'), callback_data:'owner_upgrade'}],
  [{ text:sc('📦 Senarai Reseller'), callback_data:'owner_reseller_list'}],
  [{ text:sc('📢 Broadcast'), callback_data:'owner_broadcast'}],
  [{ text:sc('🏠 Back'), callback_data:'back_main' }]
]});

function kbApprove(id) { return { inline_keyboard:[[{ text:sc('✅ APPROVE'), callback_data:`approve_${id}` },{ text:sc('❌ REJECT'), callback_data:`reject_${id}` }]] }; }
let KB_ROLE = enhanceKeyboard({ inline_keyboard:[[{ text:sc('📦 RESELLER V5'), callback_data:'role_v5' },{ text:sc('📦 RESELLER G1'), callback_data:'role_v6' }],[{ text:sc('❌ Batal'), callback_data:'cancel' }]] });
let KB_BL   = enhanceKeyboard({ inline_keyboard:[[{ text:sc('🆔 Blacklist ID Telegram'), callback_data:'bl_by_id' }],[{ text:sc('📱 Blacklist Nombor DB'), callback_data:'bl_by_nombor'}],[{ text:sc('❌ Batal'), callback_data:'cancel' }]] });

let KB_MODERATOR = enhanceKeyboard({ inline_keyboard:[
  [{ text:sc('📨 Pending Request'), callback_data:'mod_pending'},{ text:sc('📊 Statistik'), callback_data:'mod_stats'}],
  [{ text:sc('👑 Tambah Owner'), callback_data:'mod_add_owner'},{ text:sc('📋 Senarai Owner'), callback_data:'mod_list_owner'}],
  [{ text:sc('👤 Lantik Reseller'), callback_data:'mod_lantik_reseller'},{ text:sc('⬆️ Naik Taraf Reseller'), callback_data:'mod_upgrade_reseller'}],
  [{ text:sc('📦 Senarai Reseller'), callback_data:'mod_reseller_list'},{ text:sc('⚠️ Warning Reseller'), callback_data:'mod_warn_reseller'}],
  [{ text:sc('⚠️ Warning Owner'), callback_data:'mod_warn_owner'}],
  [{ text:sc('🔄 Reset Warn Reseller'), callback_data:'mod_unwarn_reseller'},{ text:sc('🔄 Reset Warn Owner'), callback_data:'mod_unwarn_owner'}],
  [{ text:sc('📋 Semua Senarai'), callback_data:'mod_list_all'},{ text:sc('🗑 Padam Nombor'), callback_data:'mod_delete_nombor'}],
  [{ text:sc('🏠 Back'), callback_data:'back_main' }]
]});

function notifyList() { const db=loadDB(); return [...new Set([...CFG.DEVELOPER_IDS,...CFG.OWNER_VVIP_IDS,...db.ownerVvip,...db.owners,...(db.moderators||[])])]; }
function isPrivate(msg) { return msg.chat.type==='private'; }
async function warnPrivate(chatId, msgId) {
  try { await bot.deleteMessage(chatId, msgId); } catch {}
  return bot.sendMessage(chatId,`${LS}\n⚠️ ${b('Mod Private Only Aktif')}\n${LS}\n\nBot ini hanya boleh digunakan melalui ${b('chat private')}.\n\n${b(CFG.GROUP_NAME)} | DATABASE SYSTEM`,
    { parse_mode:'HTML', reply_markup:{ inline_keyboard:[[{ text:sc('💬 Chat Private Bot'), url:`https://t.me/${BOT_USERNAME}` }],[{ text:sc(`🔗 Join ${CFG.GROUP_NAME}`), url:CFG.GROUP_LINK }]] }});
}

function buildStartText(userId, name) {
  const db = loadDB();
  return `🔥 ${b('KIZX BLASTER DATABASE BOT')}\n${LS}\n\n<blockquote>${b('SELAMAT DATANG, ' + String(name).toUpperCase() + '!')}\n${b('ROLE:')} ${getRoleLabel(userId).toUpperCase()}\n\n📂 ${b('KIZX V5:')} ${db.v5.length} NOMBOR\n📂 ${b('KIZX G1:')} ${db.v6.length} NOMBOR</blockquote>\n\nPILIH MENU DI BAWAH:`;
}

// ===============================================
//   /start
// ===============================================
bot.onText(/\/start/, async (msg) => {
  if (!isPrivate(msg)) return warnPrivate(msg.chat.id, msg.message_id);
  if (isBlacklisted(msg.from.id)) return bot.sendMessage(msg.chat.id,`⛔ ${b('AKSES DISEKAT')}\n${LS}\n\n<blockquote>Akun anda telah di-blacklist.</blockquote>`,{parse_mode:'HTML'});
  clrSes(msg.from.id);
  reactToMessage(msg.chat.id, msg.message_id, '🎉'); // 🔗 emoji reaction auto bila /start
  // Auto-daftar user ni untuk terima broadcast dari Developer/VVIP/Owner
  const dbReg = loadDB();
  if (!dbReg.startedUsers.includes(String(msg.chat.id))) {
    dbReg.startedUsers.push(String(msg.chat.id));
    saveDB(dbReg);
  }
  const txt = buildStartText(msg.from.id, msg.from.first_name||'User');
  if (fs.existsSync(BANNER)) {
    try {
      await bot.sendPhoto(msg.chat.id, BANNER, { caption:txt, parse_mode:'HTML', reply_markup:kbMain(msg.from.id) });
    } catch (e) {
      console.error('⚠️ Gagal hantar banner, fallback ke teks:', e.message);
      await bot.sendMessage(msg.chat.id, txt, { parse_mode:'HTML', reply_markup:kbMain(msg.from.id) });
    }
  } else {
    await bot.sendMessage(msg.chat.id, txt, { parse_mode:'HTML', reply_markup:kbMain(msg.from.id) });
  }
});

// ===============================================
//   /blacklist (group)
// ===============================================
bot.onText(/\/blacklist/, async (msg) => {
  if (!isDeveloper(msg.from.id)) return;
  if (isPrivate(msg)) return bot.sendMessage(msg.chat.id,`⚠️ Guna dalam group dengan reply mesej pengguna.`,{parse_mode:'HTML'});
  const target = msg.reply_to_message ? msg.reply_to_message.from : null;
  if (!target) return bot.sendMessage(msg.chat.id,`⚠️ Reply mesej pengguna yang ingin di-blacklist.`,{parse_mode:'HTML'});
  if (isDeveloper(target.id)) return bot.sendMessage(msg.chat.id,`⚠️ Tidak boleh blacklist Developer.`,{parse_mode:'HTML'});
  const tid = S(target.id);
  const db  = loadDB();
  if (db.blacklistIds.includes(tid)) return bot.sendMessage(msg.chat.id,`⚠️ ${c(tid)} sudah dalam blacklist.`,{parse_mode:'HTML'});
  db.blacklistIds.push(tid); saveDB(db);
  await bot.sendMessage(msg.chat.id,`⛔ <b>BLACKLIST DIKEMASKINI</b>\n\n👤 ${[target.first_name,target.last_name].filter(Boolean).join(' ')}\n🆔 ${c(tid)}\n⏰ ${masa()}`,{parse_mode:'HTML'});
});

// ===============================================
//   /info (group)
// ===============================================
bot.onText(/\/info/, async (msg) => {
  if (isPrivate(msg)) return bot.sendMessage(msg.chat.id,`⚠️ Arahan ini hanya dalam group.`,{parse_mode:'HTML'});
  const from=msg.from; const uid=from.id;
  const db=loadDB(); const mNum=db.config.members[S(uid)]||'-';
  const name=[from.first_name,from.last_name].filter(Boolean).join(' ');
  const uname=from.username?`@${from.username}`:'-';
  const rows = [
    ['Nama', name],
    ['Username', uname],
    ['ID', String(uid)],
    ['Peranan', stripTags(getRoleLabel(uid))],
    ['Member Ke', `#${mNum}`],
    ['Masa', masa()],
  ];
  await sendIdCardImage(msg.chat.id, 'MAKLUMAT PENGGUNA', rows, 'KIZX BLASTER | USER INFO SYSTEM', uid);
});

// ===============================================
//   /checkid (group or private, boleh reply / hantar ID)
// ===============================================
bot.onText(/\/checkid(?:\s+(\S+))?/, async (msg, match) => {
  const db=loadDB();
  let targetId, name, uname;
  if (msg.reply_to_message) {
    const t = msg.reply_to_message.from;
    targetId = t.id; name=[t.first_name,t.last_name].filter(Boolean).join(' '); uname = t.username?`@${t.username}`:'-';
  } else if (match && match[1]) {
    targetId = match[1].replace(/\D/g,''); name='-'; uname='-';
  } else {
    const t = msg.from;
    targetId = t.id; name=[t.first_name,t.last_name].filter(Boolean).join(' '); uname = t.username?`@${t.username}`:'-';
  }
  if (!targetId) return bot.sendMessage(msg.chat.id,`⚠️ Reply mesej atau ${c('/checkid <ID>')}.`,{parse_mode:'HTML'});
  const mNum = db.config.members[S(targetId)]||'-';
  const rows = [
    ['Nama', name],
    ['Username', uname],
    ['ID', targetId],
    ['Peranan', stripTags(getRoleLabel(targetId))],
    ['Member Ke', `#${mNum}`],
    ['Blacklist', db.blacklistIds.includes(S(targetId)) ? 'Ya' : 'Tidak'],
  ];
  await sendIdCardImage(msg.chat.id, 'CHECK ID', rows, `${CFG.GROUP_NAME} | CHECK ID SYSTEM`, targetId);
});

// ===============================================
//   /id — kad maklumat sahaja (tiada set/simpan apa-apa)
// ===============================================
bot.onText(/\/id/, async (msg) => {
  const from = msg.from;
  const name = [from.first_name, from.last_name].filter(Boolean).join(' ');
  const uname = from.username ? `@${from.username}` : '-';
  const tarikh = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kuala_Lumpur' });
  const rows = [
    ['Nama', name],
    ['User ID', String(from.id)],
    ['Username', uname],
    ['Tarikh', tarikh],
  ];
  if (!isPrivate(msg)) {
    rows.push(['Group ID', String(msg.chat.id)]);
    rows.push(['Group', msg.chat.title || '-']);
  }
  await sendIdCardImage(msg.chat.id, 'ID CARD', rows, 'KIZX BLASTER | ID SYSTEM', from.id);
});

// ===============================================
// ===============================================
//   SLASH COMMANDS
// ===============================================
bot.onText(/\/adddb/, async (msg) => {
  if (!isPrivate(msg)||isBlacklisted(msg.from.id)) return;
  if (!isResellerV5(msg.from.id)&&!isResellerV6(msg.from.id)) return bot.sendMessage(msg.chat.id,`⛔ Tiada akses.`,{parse_mode:'HTML'});
  const kb={ inline_keyboard:[] };
  if (isResellerV5(msg.from.id)) kb.inline_keyboard.push([{text:sc('📂 Tambah ke Kizx V5'),callback_data:'add_v5'}]);
  if (isResellerV6(msg.from.id)) kb.inline_keyboard.push([{text:sc('📂 Tambah ke Kizx G1'),callback_data:'add_v6'}]);
  kb.inline_keyboard.push([{text:sc('❌ Batal'),callback_data:'cancel'}]);
  return bot.sendMessage(msg.chat.id,`✅ ${b('TAMBAH DATABASE')}\n${LS}\n\nPilih versi:`,{parse_mode:'HTML',reply_markup:kb});
});

// ===============================================
//   /gemini (soalan) — AI Chat
// ===============================================
bot.onText(/\/gemini(?:\s+([\s\S]+))?/, async (msg, match) => {
  if (isBlacklisted(msg.from.id)) return;
  const question = match && match[1] ? match[1].trim() : '';
  if (!question) {
    return bot.sendMessage(msg.chat.id, `❓ Sila taip soalan selepas ${c('/gemini')}\n\nContoh: ${c('/gemini apa itu AI?')}`, { parse_mode:'HTML' });
  }
  const waitMsg = await bot.sendMessage(msg.chat.id, `🤔 ${b('Sedang berfikir...')}`, { parse_mode:'HTML' });
  try {
    const answer = await askGemini(question);
    await bot.editMessageText(`🤖 ${b('KIZX AI')}\n${LS}\n\n<blockquote>${answer}</blockquote>`, { chat_id: msg.chat.id, message_id: waitMsg.message_id, parse_mode:'HTML' });
  } catch (e) {
    await bot.editMessageText(`❌ Gagal dapatkan jawapan AI.\n\n⚠️ ${e.message}`, { chat_id: msg.chat.id, message_id: waitMsg.message_id, parse_mode:'HTML' });
  }
});

bot.onText(/\/checkdb/, async (msg) => {
  if (!isPrivate(msg)||isBlacklisted(msg.from.id)) return;
  setSes(msg.from.id,{step:'semak_all_input'});
  return bot.sendMessage(msg.chat.id,`🔎 ${b('SEMAK NOMBOR')}\n${LS}\n\n<blockquote>Masukkan nombor:\n${c('Contoh: 60123456789')}</blockquote>`,{parse_mode:'HTML',reply_markup:KB_CANCEL});
});

bot.onText(/\/exportdb/, async (msg) => {
  if (!isPrivate(msg)||!isOwner(msg.from.id)) return;
  const db=loadDB(); const ts=new Date().toISOString().slice(0,10);
  const tmp=path.join(__dirname,`db_sync_${ts}.json`);
  fs.writeFileSync(tmp,JSON.stringify(db,null,2));
  await bot.sendDocument(msg.chat.id,tmp,{caption:`📤 <b>DB EXPORT</b>\n\nV5: <b>${db.v5.length}</b> | G1: <b>${db.v6.length}</b>\nReseller: <b>${(db.resellers||[]).length}</b>\n⏰ ${masa()}`,parse_mode:'HTML'});
  fs.unlinkSync(tmp);
});

// ===============================================
//   CALLBACK QUERY HANDLER
// ===============================================
async function handleCallbackAction(cq) {
  const chatId=cq.message.chat.id, msgId=cq.message.message_id, userId=cq.from.id, data=cq.data;
  const isPhoto=!!(cq.message.photo&&cq.message.photo.length);
  try { await bot.answerCallbackQuery(cq.id); } catch {}
  if (isBlacklisted(userId)) return bot.sendMessage(chatId,`⛔ Akun anda di-blacklist.`,{parse_mode:'HTML'});

  if (data==='back_main') { clrSes(userId); const db=loadDB(); return editMsg(chatId,msgId,isPhoto,`🔥 ${b('KIZX DATABASE BOT')}\n${LS}\n\n<blockquote>📂 ${b('Kizx V5:')} ${db.v5.length} nombor\n📂 ${b('Kizx G1:')} ${db.v6.length} nombor\n\nRole: ${b(getRoleLabel(userId))}\n</blockquote>\nPilih menu:`,{reply_markup:kbMain(userId)}); }
  if (data==='cancel')    { clrSes(userId); return editMsg(chatId,msgId,isPhoto,`❌ ${b('Tindakan dibatalkan.')}`,{reply_markup:kbMain(userId)}); }

  // -- DEV PANEL --------------------------------
  if (data==='superdev_panel') {
    if (!isSuperDeveloper(userId)) return editMsg(chatId,msgId,isPhoto,`⛔ ${b('AKSES DITOLAK')}`,{reply_markup:kbMain(userId)});
    const db=loadDB();
    const cur = CFG.getDomainConfig();
    return editMsg(chatId,msgId,isPhoto,`⚡ ${b('SUPER DEVELOPER PANEL')}\n${LS}\n\n<blockquote>📂 Kizx V5: ${b(String(db.v5.length))} | Kizx G1: ${b(String(db.v6.length))}\n💎 Super Owner: ${b(String(CFG.OWNER_VVIP_IDS.length+db.ownerVvip.length))}\n👑 Owner: ${b(String(db.owners.length))}\n🛡️ Moderator: ${b(String((db.moderators||[]).length))}\n📦 Reseller: ${b(String(db.resellers.length))}\n⛔ Blacklist: ${b(String(db.blacklistIds.length+db.blacklistNombor.length))}\n📌 Pending: ${b(String(Object.keys(pending).length))}\n🌐 Domain: ${c(cur || '(belum ditetapkan)')}\n🧑‍💻 Developer dilantik: ${b(String(db.developers.length))}\n</blockquote>\nPilih tindakan:`,{reply_markup:KB_SUPER_DEV});
  }
  if (data==='superdev_add_dev') {
    if (!isSuperDeveloper(userId)) return;
    setSes(userId,{step:'superdev_add_dev_input'});
    return editMsg(chatId,msgId,isPhoto,`🧑‍💻 ${b('TAMBAH DEVELOPER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID untuk dilantik jadi Developer:</blockquote>`,{reply_markup:KB_CANCEL});
  }
  if (data==='superdev_rm_dev') {
    if (!isSuperDeveloper(userId)) return;
    setSes(userId,{step:'superdev_rm_dev_input'});
    return editMsg(chatId,msgId,isPhoto,`🗑 ${b('BUANG DEVELOPER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID Developer untuk dibuang:</blockquote>`,{reply_markup:KB_CANCEL});
  }
  if (data==='superdev_list_dev') {
    if (!isSuperDeveloper(userId)) return;
    const db=loadDB();
    const hardcoded = CFG.DEVELOPER_IDS.filter(id=>!CFG.SUPER_DEVELOPER_IDS.includes(id)).map(id=>`${c(id)} (tetap)`);
    const dynamic = db.developers.map(id=>c(id));
    const all = [...hardcoded, ...dynamic];
    const list = all.length ? all.map((x,i)=>`${i+1}. ${x}`).join('\n') : '(tiada)';
    return editMsg(chatId,msgId,isPhoto,`📋 ${b('SENARAI DEVELOPER')}\n${LS}\n\n<blockquote>${list}</blockquote>`,{parse_mode:'HTML',reply_markup:KB_SUPER_DEV});
  }
  if (data==='dev_panel') {
    if (!isDeveloper(userId)) return editMsg(chatId,msgId,isPhoto,`⛔ ${b('AKSES DITOLAK')}`,{reply_markup:kbMain(userId)});
    const db=loadDB();
    return editMsg(chatId,msgId,isPhoto,`🧑‍💻 ${b('DEVELOPER PANEL')}\n${LS}\n\n<blockquote>📂 Kizx V5: ${b(String(db.v5.length))} | Kizx G1: ${b(String(db.v6.length))}\n💎 Super Owner: ${b(String(CFG.OWNER_VVIP_IDS.length+db.ownerVvip.length))}\n👑 Owner: ${b(String(db.owners.length))}\n🛡️ Moderator: ${b(String((db.moderators||[]).length))}\n📦 Reseller: ${b(String(db.resellers.length))}\n⛔ Blacklist: ${b(String(db.blacklistIds.length+db.blacklistNombor.length))}\n📌 Pending: ${b(String(Object.keys(pending).length))}\n</blockquote>\nPilih tindakan:`,{reply_markup:KB_DEV});
  }
  if (data==='dev_stats') {
    if (!isDeveloper(userId)) return;
    const db=loadDB(); const ses=loadSes();
    return editMsg(chatId,msgId,isPhoto,`📊 ${b('STATISTIK PENUH')}\n${LS}\n\n<blockquote>📂 Kizx V5: ${b(String(db.v5.length))} rekod\n📂 Kizx G1: ${b(String(db.v6.length))} rekod\n\n🧑‍💻 Developer: ${b(String(CFG.DEVELOPER_IDS.length))}\n💎 Super Owner: ${b(String(CFG.OWNER_VVIP_IDS.length+db.ownerVvip.length))}\n👑 Owner: ${b(String(db.owners.length))}\n🛡️ Moderator: ${b(String((db.moderators||[]).length))}\n📦 Reseller: ${b(String(db.resellers.length))}\n\n⛔ Blacklist ID: ${b(String(db.blacklistIds.length))}\n⛔ Blacklist Nom: ${b(String(db.blacklistNombor.length))}\n\n📌 Pending: ${b(String(Object.keys(pending).length))}\n🔄 Sesi Aktif: ${b(String(Object.keys(ses).length))}\n\n🏢 Group: ${db.config.groupId?c(db.config.groupId):i('Belum ditetapkan')}\n⏰ ${masa()}</blockquote>`,{reply_markup:KB_DEV});
  }
  if (data==='dev_list_vvip') {
    if (!isDeveloper(userId)) return;
    const db=loadDB();
    const hard=CFG.OWNER_VVIP_IDS.map((id,i)=>`${i+1}. ${c(id)} ${i('(config)')}`).join('\n');
    const dyn=db.ownerVvip.length?db.ownerVvip.map((id,i)=>`${i+1}. ${c(id)} ${i('(dynamic)')}`).join('\n'):'Tiada';
    return editMsg(chatId,msgId,isPhoto,`💎 ${b('SENARAI SUPER OWNER')}\n${LS}\n\n<blockquote>${b('Hardcoded:')}\n${hard}\n\n${b('Dynamic:')}\n${dyn}</blockquote>`,{reply_markup:KB_DEV});
  }
  if (data==='dev_add_owner') { if (!isDeveloper(userId)) return; setSes(userId,{step:'dev_add_owner_input'}); return editMsg(chatId,msgId,isPhoto,`👑 ${b('TAMBAH OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID Owner baru:\n${c('Contoh: 123456789')}</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_rm_owner')  { if (!isDeveloper(userId)) return; setSes(userId,{step:'dev_rm_owner_input'}); return editMsg(chatId,msgId,isPhoto,`🗑 ${b('BUANG OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID Owner:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_list_owner') { if (!isDeveloper(userId)) return; const db=loadDB(); const txt=db.owners.length?db.owners.map((id,i)=>`${i+1}. ${c(id)}`).join('\n'):'Tiada owner.'; return editMsg(chatId,msgId,isPhoto,`👑 ${b('SENARAI OWNER')} (${db.owners.length})\n${LS}\n\n<blockquote>${txt}</blockquote>`,{reply_markup:KB_DEV}); }
  if (data==='dev_add_vvip')  { if (!isDeveloper(userId)) return; setSes(userId,{step:'dev_add_vvip_input'}); return editMsg(chatId,msgId,isPhoto,`💎 ${b('TAMBAH SUPER OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID:\n${c('Contoh: 123456789')}</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_rm_vvip')   { if (!isDeveloper(userId)) return; setSes(userId,{step:'dev_rm_vvip_input'}); return editMsg(chatId,msgId,isPhoto,`🗑 ${b('BUANG SUPER OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID:\n${c('(Hanya dynamic, bukan config.js)')}</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_add_mod')   { if (!isDeveloper(userId)&&!isOwnerVvip(userId)) return; setSes(userId,{step:'dev_add_mod_input'}); return editMsg(chatId,msgId,isPhoto,`🛡️ ${b('TAMBAH MODERATOR')}\n${LS}\n\n<blockquote>Masukkan Telegram ID:\n${c('Contoh: 123456789')}</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_rm_mod')    { if (!isDeveloper(userId)&&!isOwnerVvip(userId)) return; setSes(userId,{step:'dev_rm_mod_input'}); return editMsg(chatId,msgId,isPhoto,`🗑 ${b('BUANG MODERATOR')}\n${LS}\n\n<blockquote>Masukkan Telegram ID Moderator:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_list_mod')  { if (!isDeveloper(userId)&&!isOwnerVvip(userId)) return; const db=loadDB(); const txt=(db.moderators||[]).length?(db.moderators).map((id,i)=>`${i+1}. ${c(id)}`).join('\n'):'Tiada moderator.'; return editMsg(chatId,msgId,isPhoto,`🛡️ ${b('SENARAI MODERATOR')} (${(db.moderators||[]).length})\n${LS}\n\n<blockquote>${txt}</blockquote>`,{reply_markup:KB_DEV}); }
  if (data==='dev_clear_ses') { if (!isDeveloper(userId)) return; clrAllSes(); return editMsg(chatId,msgId,isPhoto,`✅ ${b('SEMUA SESI DIBERSIHKAN!')}`,{reply_markup:KB_DEV}); }
  if (data==='dev_pending') {
    if (!isDeveloper(userId)) return;
    const list=Object.entries(pending);
    if (!list.length) return editMsg(chatId,msgId,isPhoto,`📨 ${b('TIADA PENDING')}`,{reply_markup:KB_DEV});
    let txt=`📨 ${b('SEMUA PENDING')} (${list.length})\n${LS}\n\n<blockquote>`;
    list.slice(0,15).forEach(([id,r])=>{ txt+=`#${id} - DB ${verLabel(r.ver)} - ${r.type==='add'?'TAMBAH':'TUKAR'}\n`; if(r.type==='add') txt+=`${c(r.nombor)} | ${r.panel}\n\n`; else txt+=`${c(r.nomborLama)} → ${c(r.nomborBaru)}\n\n`; });
    txt+='</blockquote>';
    return editMsg(chatId,msgId,isPhoto,txt,{reply_markup:KB_DEV});
  }
  if (data==='dev_backup') { if (!isDeveloper(userId)) return; doBackup(loadDB()); sendScheduledBackup(); return editMsg(chatId,msgId,isPhoto,`💾 ${b('BACKUP MANUAL BERJAYA!')}\n\nFail backup dihantar ke semua developer/owner/VVIP.`,{reply_markup:KB_DEV}); }
  if (data==='dev_export') {
    if (!isDeveloper(userId)) return;
    const db=loadDB(); const ts=new Date().toISOString().slice(0,10); const tmp=path.join(__dirname,`dev_export_${ts}.json`);
    fs.writeFileSync(tmp,JSON.stringify(db,null,2));
    await bot.sendDocument(chatId,tmp,{caption:`📤 ${b('DEVELOPER EXPORT')}\n\nV5: ${db.v5.length} | G1: ${db.v6.length}`,parse_mode:'HTML'});
    fs.unlinkSync(tmp); return;
  }
  if (data==='dev_broadcast') { if (!isDeveloper(userId)) return; setSes(userId,{step:'broadcast_all_input',panel:'dev'}); return editMsg(chatId,msgId,isPhoto,`📢 ${b('BROADCAST (GROUP + USER)')}\n${LS}\n\n<blockquote>Masukkan mesej:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_add_resell') { if (!isDeveloper(userId)) return; setSes(userId,{step:'lantik_username'}); return editMsg(chatId,msgId,isPhoto,`📦 ${b('TAMBAH RESELL')}\n${LS}\n\n<blockquote>📋 Langkah 1/4\nMasukkan ${b('@username')} reseller:\n${c('Contoh: @kizxstore')}</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_bl_id')  { if (!isDeveloper(userId)) return; setSes(userId,{step:'dev_bl_id_input'}); return editMsg(chatId,msgId,isPhoto,`⛔ ${b('BLACKLIST ID')}\n${LS}\n\n<blockquote>Masukkan Telegram ID:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_bl_nom') { if (!isDeveloper(userId)) return; setSes(userId,{step:'dev_bl_nom_input'}); return editMsg(chatId,msgId,isPhoto,`📱 ${b('BLACKLIST NOMBOR')}\n${LS}\n\n<blockquote>Masukkan nombor:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_warn_reseller') { if (!isDeveloper(userId)) return; setSes(userId,{step:'warn_target_id',panel:'dev',targetType:'reseller'}); return editMsg(chatId,msgId,isPhoto,`⚠️ ${b('WARNING RESELLER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID reseller:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_warn_owner') { if (!isDeveloper(userId)) return; setSes(userId,{step:'warn_target_id',panel:'dev',targetType:'owner'}); return editMsg(chatId,msgId,isPhoto,`⚠️ ${b('WARNING OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID owner:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_unwarn_reseller') { if (!isDeveloper(userId)) return; setSes(userId,{step:'unwarn_target_id',panel:'dev',targetType:'reseller'}); return editMsg(chatId,msgId,isPhoto,`🔄 ${b('RESET WARNING RESELLER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID reseller untuk reset warning (0/3):</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_unwarn_owner') { if (!isDeveloper(userId)) return; setSes(userId,{step:'unwarn_target_id',panel:'dev',targetType:'owner'}); return editMsg(chatId,msgId,isPhoto,`🔄 ${b('RESET WARNING OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID owner untuk reset warning (0/3):</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_bl_rm') { if (!isDeveloper(userId)) return; setSes(userId,{step:'dev_bl_rm_input'}); return editMsg(chatId,msgId,isPhoto,`✅ ${b('UNBLACKLIST')}\n${LS}\n\n<blockquote>Masukkan ID Telegram ATAU nombor yang ingin dibuang dari blacklist:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='dev_domain') {
    if (!isSuperDeveloper(userId)) return bot.sendMessage(chatId,`⛔ Hanya Super Developer boleh tukar domain.`,{parse_mode:'HTML'});
    setSes(userId,{step:'dev_domain_input'});
    const cur = CFG.getDomainConfig();
    return editMsg(chatId,msgId,isPhoto,`🌐 ${b('DOMAIN API')}\n${LS}\n\n<blockquote>Semasa:\n${c(cur || '(belum ditetapkan)')}</blockquote>\n\nMasukkan domain baru (${c('http://domain:port')} — WAJIB http, BUKAN https):`,{parse_mode:'HTML',reply_markup:KB_CANCEL});
  }
  if (data==='vvip_warn_owner') { if (!isOwnerVvip(userId)) return; setSes(userId,{step:'warn_target_id',panel:'vvip',targetType:'owner'}); return editMsg(chatId,msgId,isPhoto,`⚠️ ${b('WARNING OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID owner:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='vvip_warn_reseller') { if (!isOwnerVvip(userId)) return; setSes(userId,{step:'warn_target_id',panel:'vvip',targetType:'reseller'}); return editMsg(chatId,msgId,isPhoto,`⚠️ ${b('WARNING RESELLER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID reseller:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='vvip_unwarn_owner') { if (!isOwnerVvip(userId)) return; setSes(userId,{step:'unwarn_target_id',panel:'vvip',targetType:'owner'}); return editMsg(chatId,msgId,isPhoto,`🔄 ${b('RESET WARNING OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID owner untuk reset warning (0/3):</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='vvip_unwarn_reseller') { if (!isOwnerVvip(userId)) return; setSes(userId,{step:'unwarn_target_id',panel:'vvip',targetType:'reseller'}); return editMsg(chatId,msgId,isPhoto,`🔄 ${b('RESET WARNING RESELLER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID reseller untuk reset warning (0/3):</blockquote>`,{reply_markup:KB_CANCEL}); }

  // -- SUPER OWNER PANEL ------------------------
  if (data==='vvip_panel') { if (!isOwnerVvip(userId)) return editMsg(chatId,msgId,isPhoto,`⛔ ${b('AKSES DITOLAK')}`,{reply_markup:kbMain(userId)}); return editMsg(chatId,msgId,isPhoto,`💎 ${b('SUPER OWNER PANEL')}\n${LS}\n\n<blockquote>Role: ${b(getRoleLabel(userId))}</blockquote>`,{reply_markup:KB_VVIP}); }
  if (data==='vvip_backup') { if (!isOwnerVvip(userId)) return; doBackup(loadDB()); return editMsg(chatId,msgId,isPhoto,`💾 ${b('BACKUP BERJAYA!')}`,{reply_markup:KB_VVIP}); }
  if (data==='vvip_list_owner') { if (!isOwnerVvip(userId)) return; const db=loadDB(); const txt=db.owners.length?db.owners.map((id,i)=>`${i+1}. ${c(id)}`).join('\n'):'Tiada.'; return editMsg(chatId,msgId,isPhoto,`👑 ${b('SENARAI OWNER')} (${db.owners.length})\n${LS}\n\n<blockquote>${txt}</blockquote>`,{reply_markup:KB_VVIP}); }
  if (data==='vvip_add_owner') { if (!isOwnerVvip(userId)) return; setSes(userId,{step:'vvip_add_owner_input'}); return editMsg(chatId,msgId,isPhoto,`👑 ${b('TAMBAH OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID:\n${c('Contoh: 123456789')}</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='vvip_rm_owner')  { if (!isOwnerVvip(userId)) return; setSes(userId,{step:'vvip_rm_owner_input'}); return editMsg(chatId,msgId,isPhoto,`🗑 ${b('BUANG OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='vvip_setgroup')  { if (!isSuperDeveloper(userId)) return bot.sendMessage(chatId,`⛔ Hanya Super Developer boleh set group.`,{parse_mode:'HTML'}); setSes(userId,{step:'vvip_setgroup_input'}); return editMsg(chatId,msgId,isPhoto,`🏢 ${b('SET GROUP ID')}\n${LS}\n\n<blockquote>Masukkan Group ID (${c('-100...')}):</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='vvip_bl_add')    { if (!isOwnerVvip(userId)) return; return editMsg(chatId,msgId,isPhoto,`⛔ ${b('TAMBAH BLACKLIST')}\n${LS}\n\n<blockquote>Pilih jenis:</blockquote>`,{reply_markup:KB_BL}); }
  if (data==='bl_by_id')       { setSes(userId,{step:'bl_add_id'}); return editMsg(chatId,msgId,isPhoto,`⛔ ${b('BLACKLIST ID')}\n${LS}\n\n<blockquote>Masukkan Telegram ID:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='bl_by_nombor')   { setSes(userId,{step:'bl_add_nombor'}); return editMsg(chatId,msgId,isPhoto,`⛔ ${b('BLACKLIST NOMBOR')}\n${LS}\n\n<blockquote>Masukkan nombor:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='vvip_bl_list') {
    if (!isOwnerVvip(userId)) return;
    const db=loadDB();
    const ids=db.blacklistIds.length?db.blacklistIds.map((x,i)=>`${i+1}. ${c(x)}`).join('\n'):'Tiada';
    const nom=db.blacklistNombor.length?db.blacklistNombor.map((x,i)=>`${i+1}. ${c(x)}`).join('\n'):'Tiada';
    return editMsg(chatId,msgId,isPhoto,`⛔ ${b('SENARAI BLACKLIST')}\n${LS}\n\n<blockquote>🆔 ${b('ID:')}\n${ids}\n\n📱 ${b('Nombor:')}\n${nom}</blockquote>`,{reply_markup:KB_VVIP});
  }
  if (data==='vvip_bl_rm')     { if (!isOwnerVvip(userId)) return; setSes(userId,{step:'bl_rm_input'}); return editMsg(chatId,msgId,isPhoto,`🗑 ${b('BUANG BLACKLIST')}\n${LS}\n\n<blockquote>Masukkan ID atau nombor:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='vvip_broadcast') { if (!isOwnerVvip(userId)) return; setSes(userId,{step:'broadcast_all_input',panel:'vvip'}); return editMsg(chatId,msgId,isPhoto,`📢 ${b('BROADCAST (GROUP + USER)')}\n${LS}\n\n<blockquote>Masukkan mesej:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='vvip_export_all') {
    if (!isOwnerVvip(userId)) return;
    const db=loadDB(); const ts=new Date().toISOString().slice(0,10); const tmp=path.join(__dirname,`db_full_${ts}.json`);
    fs.writeFileSync(tmp,JSON.stringify(db,null,2));
    await bot.sendDocument(chatId,tmp,{caption:`📤 ${b('EXPORT PENUH')}\n\nV5: ${db.v5.length} | G1: ${db.v6.length}`,parse_mode:'HTML'});
    fs.unlinkSync(tmp); return;
  }

  // -- OWNER PANEL ------------------------------
  if (data==='owner_panel') { if (!isOwner(userId)) return editMsg(chatId,msgId,isPhoto,`⛔ ${b('AKSES DITOLAK')}`,{reply_markup:kbMain(userId)}); return editMsg(chatId,msgId,isPhoto,`👑 ${b('OWNER PANEL')}\n${LS}\n\n<blockquote>Role: ${b(getRoleLabel(userId))}</blockquote>`,{reply_markup:KB_OWNER}); }
  if (data==='owner_stats') { if (!isOwner(userId)) return; const db=loadDB(); return editMsg(chatId,msgId,isPhoto,`📊 ${b('STATISTIK')}\n${LS}\n\n<blockquote>📂 Kizx V5: ${b(String(db.v5.length))}\n📂 Kizx G1: ${b(String(db.v6.length))}\n\n👑 Owners: ${b(String(db.owners.length))}\n📦 Resellers: ${b(String(db.resellers.length))}\n⛔ Blacklist: ${b(String(db.blacklistIds.length+db.blacklistNombor.length))}\n📌 Pending: ${b(String(Object.keys(pending).length))}</blockquote>`,{reply_markup:KB_OWNER}); }
  if (data==='owner_pending') {
    if (!isOwner(userId)) return;
    const list=Object.entries(pending);
    if (!list.length) return editMsg(chatId,msgId,isPhoto,`📨 ${b('TIADA PENDING')}`,{reply_markup:KB_OWNER});
    let txt=`📨 ${b('PENDING')} (${list.length})\n${LS}\n\n<blockquote>`;
    list.slice(0,10).forEach(([id,r])=>{ txt+=`#${id} - ${b('DB '+verLabel(r.ver))}\n${r.type==='add'?c(r.nombor)+' | '+r.panel:c(r.nomborLama)+' → '+c(r.nomborBaru)}\n\n`; });
    txt+='</blockquote>';
    return editMsg(chatId,msgId,isPhoto,txt,{reply_markup:KB_OWNER});
  }
  if (data==='owner_list_all') {
    if (!isOwner(userId)) return;
    const db=loadDB();
    const r5=db.v5.length?db.v5.slice(0,20).map((e,i)=>`${i+1}. ${c(e.nombor)} - ${e.panel}`).join('\n'):'Tiada';
    const r6=db.v6.length?db.v6.slice(0,20).map((e,i)=>`${i+1}. ${c(e.nombor)} - ${e.panel}`).join('\n'):'Tiada';
    return editMsg(chatId,msgId,isPhoto,`📋 ${b('SEMUA SENARAI')}\n${LS}\n\n<blockquote>📂 ${b('Kizx V5')} (${db.v5.length}):\n${r5}\n\n📂 ${b('Kizx G1')} (${db.v6.length}):\n${r6}</blockquote>`,{reply_markup:KB_OWNER});
  }
  if (data==='owner_delete')       { if (!isOwner(userId)) return; setSes(userId,{step:'owner_delete_input'}); return editMsg(chatId,msgId,isPhoto,`🗑 ${b('PADAM NOMBOR')}\n${LS}\n\n<blockquote>Masukkan nombor:\n${c('Contoh: 60123456789')}</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='owner_lantik')       { if (!isOwner(userId)) return; setSes(userId,{step:'lantik_username'}); return editMsg(chatId,msgId,isPhoto,`👤 ${b('LANTIK RESELLER')}\n${LS}\n\n<blockquote>📋 Langkah 1/3\nMasukkan ${b('@username')}:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='owner_reseller_list') { if (!isOwner(userId)) return; const db=loadDB(); if (!db.resellers.length) return editMsg(chatId,msgId,isPhoto,`📦 Tiada reseller.`,{reply_markup:KB_OWNER}); const rows=db.resellers.map((r,i)=>`${i+1}. ${b(r.username)}\n    Role: ${r.role}\n    ID: ${c(r.userId)}`).join('\n\n'); return editMsg(chatId,msgId,isPhoto,`📦 ${b('SENARAI RESELLER')} (${db.resellers.length})\n${LS}\n\n<blockquote>${rows}</blockquote>`,{reply_markup:KB_OWNER}); }
  if (data==='owner_upgrade')      { if (!isOwner(userId)) return; setSes(userId,{step:'upgrade_reseller_input'}); return editMsg(chatId,msgId,isPhoto,`⬆️ ${b('NAIK TARAF RESELLER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID reseller:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='owner_broadcast')    { if (!isOwner(userId)) return; setSes(userId,{step:'broadcast_all_input',panel:'owner'}); return editMsg(chatId,msgId,isPhoto,`📢 ${b('BROADCAST (GROUP + USER)')}\n${LS}\n\n<blockquote>Masukkan mesej:</blockquote>`,{reply_markup:KB_CANCEL}); }

  if (data==='confirm_upgrade') {
    if (!isOwner(userId)&&!isModerator(userId)) return;
    const sess=getSes(userId); if (!sess||sess.step!=='upgrade_confirm') return;
    clrSes(userId); const db=loadDB(); const idx=db.resellers.findIndex(r=>r.userId===sess.targetId);
    if (idx===-1) return editMsg(chatId,msgId,isPhoto,`⚠️ Reseller tidak dijumpai.`,{reply_markup:KB_OWNER});
    const aTag=cq.from.username?`@${cq.from.username}`:cq.from.first_name; const ms=masa();
    db.resellers[idx].role=sess.newRole; db.resellers[idx].naik_oleh=aTag; db.resellers[idx].naik_tarikh=ms;
    saveDB(db);
    const notif=`${LS}\n⬆️🎉 ${b('RESELLER DINAIKKAN TARAF!')}\n${LS}\n\n👤 ${b(sess.username)}\n🆔 ${c(sess.targetId)}\n📦 Dari: ${b(sess.oldRole)} → ${b(sess.newRole)}\n👑 Oleh: ${b(aTag)}\n⏰ ${ms}\n\n${b(CFG.GROUP_NAME)} | ROLE MANAGEMENT`;
    await notifyOfficialGroups(notif);
    for (const sid of notifyList()) { try { await bot.sendMessage(sid,notif,{parse_mode:'HTML'}); } catch {} }
    const kbAfterUpgrade = sess.backTo==='mod' ? KB_MODERATOR : KB_OWNER;
    return editMsg(chatId,msgId,isPhoto,`✅ ${b('NAIK TARAF BERJAYA!')}\n\n${b(sess.username)}\n${b(sess.oldRole)} → ${b(sess.newRole)}`,{reply_markup:kbAfterUpgrade});
  }

  if (data==='role_v5'||data==='role_v6') {
    const sess=getSes(userId); if (!sess||sess.step!=='lantik_role') return;
    if (!isOwner(userId)&&!isModerator(userId)) return;
    const ver=data==='role_v5'?'V5':'G1'; const aTag=cq.from.username?`@${cq.from.username}`:cq.from.first_name; const ms=masa();
    const db=loadDB(); db.resellers=db.resellers.filter(r=>r.userId!==sess.resellerId);
    db.resellers.push({username:sess.username,userId:sess.resellerId,role:`RESELLER ${ver}`,lantikOleh:aTag,tarikh:ms}); saveDB(db); clrSes(userId);
    const notif=`🎉📦 <b>RESELLER ${ver} BARU TELAH DILANTIK!</b>\n${LS}\n\n<blockquote>👤 <b>Ahli</b>     : ${sess.nama||sess.username}\n🆔 <b>ID</b>       : ${c(sess.resellerId)}\n🛡️ <b>Peranan</b>  : RESELLER ${ver}\n👑 <b>Dilantik</b> : ${aTag}\n⏰ <b>Masa</b>     : ${ms}</blockquote>\n\n<blockquote>🌟 Tahniah! Anda kini rasmi menjadi sebahagian daripada pasukan KIZX. Gunakan akses dan tanggungjawab ini dengan penuh profesionalisme.</blockquote>\n\n<b>KIZX BLASTER</b> | ROLE MANAGEMENT SYSTEM`;
    await notifyOfficialGroups(notif);
    for (const sid of notifyList()) { try { await bot.sendMessage(sid,notif,{parse_mode:'HTML'}); } catch {} }
    const kbAfterLantik = sess.backTo==='mod' ? KB_MODERATOR : KB_OWNER;
    return editMsg(chatId,msgId,isPhoto,`✅ ${b('RESELLER DILANTIK!')}\n\n${b(sess.username)} → 📦 ${b(`RESELLER ${ver}`)}`,{reply_markup:kbAfterLantik});
  }

  if (data==='menu_v5'||data==='menu_v6') { const ver=data==='menu_v5'?'v5':'v6'; const db=loadDB(); return editMsg(chatId,msgId,isPhoto,`📂 ${b('DATABASE '+verLabel(ver))}\n${LS}\n\n<blockquote>Jumlah: ${b(String(db[ver].length))} nombor\n</blockquote>\nPilih tindakan:`,{reply_markup:kbDB(ver,userId)}); }
  if (data==='semak_all') { setSes(userId,{step:'semak_all_input'}); return editMsg(chatId,msgId,isPhoto,`🔎 ${b('SEMAK NOMBOR')}\n${LS}\n\n<blockquote>Masukkan nombor:\n${c('Contoh: 60123456789')}</blockquote>`,{reply_markup:KB_CANCEL}); }

  if (data.startsWith('add_')&&!data.startsWith('add2_')) { const ver=data.replace('add_',''); if ((ver==='v5'&&!isResellerV5(userId))||(ver==='v6'&&!isResellerV6(userId))) return bot.sendMessage(chatId,`⛔ Tiada akses.`,{parse_mode:'HTML'}); setSes(userId,{step:'add_resit',ver}); return editMsg(chatId,msgId,isPhoto,`✅ ${b('TAMBAH NOMBOR - DB '+verLabel(ver))}\n${LS}\n\n<blockquote>📋 Langkah 1/3\nHantar ${b('gambar resit')} payment:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data.startsWith('add2_')) { const ver=data.replace('add2_',''); if ((ver==='v5'&&!isResellerV5(userId))||(ver==='v6'&&!isResellerV6(userId))) return bot.sendMessage(chatId,`⛔ Tiada akses.`,{parse_mode:'HTML'}); setSes(userId,{step:'add2_nombor_lama',ver}); return editMsg(chatId,msgId,isPhoto,`📱 ${b('TAMBAH NOMBOR 2 - DB '+verLabel(ver))}\n${LS}\n\n<blockquote>📋 Langkah 1/4\nMasukkan ${b('nombor lama')}:\n${c('Contoh: 60123456789')}</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data.startsWith('check_')) { const ver=data.replace('check_',''); setSes(userId,{step:'check_nombor',ver}); return editMsg(chatId,msgId,isPhoto,`🔎 ${b('SEMAK NOMBOR - DB '+verLabel(ver))}\n${LS}\n\n<blockquote>Masukkan nombor:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data.startsWith('list_')) { const ver=data.replace('list_',''); const db=loadDB(); const list=db[ver]; if (!list.length) return editMsg(chatId,msgId,isPhoto,`📋 ${b('SENARAI DB '+verLabel(ver))}\n${LS}\n\n<blockquote>Tiada data.</blockquote>`,{reply_markup:kbDB(ver,userId)}); const rows=list.slice(0,50).map((e,i)=>`${i+1}. ${c(e.nombor)} - ${b(e.panel)}`).join('\n'); const extra=list.length>50?`\n\n${i('...dan '+(list.length-50)+' lagi.')}`:''; return editMsg(chatId,msgId,isPhoto,`📋 ${b('SENARAI DB '+verLabel(ver))} (${list.length})\n${LS}\n\n<blockquote>${rows}${extra}</blockquote>`,{reply_markup:kbDB(ver,userId)}); }
  if (data.startsWith('export_')) { const ver=data.replace('export_',''); if (!isOwner(userId)) return; const db=loadDB(); const ts=new Date().toISOString().slice(0,10); const tmp=path.join(__dirname,`db_${ver}_${ts}.json`); fs.writeFileSync(tmp,JSON.stringify(db[ver],null,2)); await bot.sendDocument(chatId,tmp,{caption:`📤 ${b('Export DB '+verLabel(ver))}\n\nJumlah: ${b(String(db[ver].length))}\nTarikh: ${ts}`,parse_mode:'HTML'}); fs.unlinkSync(tmp); return; }
  if (data==='skip_ulasan2') { const sess=getSes(userId); if (!sess) return; return submitAdd2(chatId,userId,{...sess,ulasan:'-'}); }

  // -- MODERATOR PANEL --------------------------
  if (data==='mod_panel') {
    if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return editMsg(chatId,msgId,isPhoto,`⛔ ${b('AKSES DITOLAK')}`,{reply_markup:kbMain(userId)});
    return editMsg(chatId,msgId,isPhoto,`🛡️ ${b('MODERATOR PANEL')}\n${LS}\n\n<blockquote>Role: ${b(getRoleLabel(userId))}</blockquote>`,{reply_markup:KB_MODERATOR});
  }
  if (data==='mod_stats') {
    if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return;
    const db=loadDB();
    return editMsg(chatId,msgId,isPhoto,`📊 ${b('STATISTIK')}\n${LS}\n\n<blockquote>📂 Kizx V5: ${b(String(db.v5.length))}\n📂 Kizx G1: ${b(String(db.v6.length))}\n\n👑 Owners: ${b(String(db.owners.length))}\n🛡️ Moderator: ${b(String((db.moderators||[]).length))}\n📦 Resellers: ${b(String(db.resellers.length))}\n⛔ Blacklist: ${b(String(db.blacklistIds.length+db.blacklistNombor.length))}\n📌 Pending: ${b(String(Object.keys(pending).length))}</blockquote>`,{reply_markup:KB_MODERATOR});
  }
  if (data==='mod_pending') {
    if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return;
    const list=Object.entries(pending);
    if (!list.length) return editMsg(chatId,msgId,isPhoto,`📨 ${b('TIADA PENDING')}`,{reply_markup:KB_MODERATOR});
    let txt=`📨 ${b('PENDING')} (${list.length})\n${LS}\n\n<blockquote>`;
    list.slice(0,10).forEach(([id,r])=>{ txt+=`#${id} - ${b('DB '+verLabel(r.ver))}\n${r.type==='add'?c(r.nombor)+' | '+r.panel:c(r.nomborLama)+' → '+c(r.nomborBaru)}\n\n`; });
    txt+='</blockquote>';
    return editMsg(chatId,msgId,isPhoto,txt,{reply_markup:KB_MODERATOR});
  }
  if (data==='mod_list_all') {
    if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return;
    const db=loadDB();
    const r5=db.v5.length?db.v5.slice(0,20).map((e,i)=>`${i+1}. ${c(e.nombor)} - ${e.panel}`).join('\n'):'Tiada';
    const r6=db.v6.length?db.v6.slice(0,20).map((e,i)=>`${i+1}. ${c(e.nombor)} - ${e.panel}`).join('\n'):'Tiada';
    return editMsg(chatId,msgId,isPhoto,`📋 ${b('SEMUA SENARAI')}\n${LS}\n\n<blockquote>📂 ${b('Kizx V5')} (${db.v5.length}):\n${r5}\n\n📂 ${b('Kizx G1')} (${db.v6.length}):\n${r6}</blockquote>`,{reply_markup:KB_MODERATOR});
  }
  if (data==='mod_reseller_list') {
    if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return;
    const db=loadDB();
    if (!db.resellers.length) return editMsg(chatId,msgId,isPhoto,`📦 Tiada reseller.`,{reply_markup:KB_MODERATOR});
    const rows=db.resellers.map((r,i)=>`${i+1}. ${b(r.username)}\n    Role: ${r.role}\n    ID: ${c(r.userId)}`).join('\n\n');
    return editMsg(chatId,msgId,isPhoto,`📦 ${b('SENARAI RESELLER')} (${db.resellers.length})\n${LS}\n\n<blockquote>${rows}</blockquote>`,{reply_markup:KB_MODERATOR});
  }
  if (data==='mod_warn_reseller')    { if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return; setSes(userId,{step:'warn_target_id',panel:'mod',targetType:'reseller'}); return editMsg(chatId,msgId,isPhoto,`⚠️ ${b('WARNING RESELLER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID reseller:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='mod_warn_owner')       { if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return; setSes(userId,{step:'warn_target_id',panel:'mod',targetType:'owner'}); return editMsg(chatId,msgId,isPhoto,`⚠️ ${b('WARNING OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID owner:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='mod_unwarn_reseller')  { if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return; setSes(userId,{step:'unwarn_target_id',panel:'mod',targetType:'reseller'}); return editMsg(chatId,msgId,isPhoto,`🔄 ${b('RESET WARNING RESELLER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID reseller untuk reset warning (0/3):</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='mod_unwarn_owner')     { if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return; setSes(userId,{step:'unwarn_target_id',panel:'mod',targetType:'owner'}); return editMsg(chatId,msgId,isPhoto,`🔄 ${b('RESET WARNING OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID owner untuk reset warning (0/3):</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='mod_add_owner')        { if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return; setSes(userId,{step:'mod_add_owner_input'}); return editMsg(chatId,msgId,isPhoto,`👑 ${b('TAMBAH OWNER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID Owner baru:\n${c('Contoh: 123456789')}</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='mod_list_owner')       { if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return; const db=loadDB(); const txt=db.owners.length?db.owners.map((id,i)=>`${i+1}. ${c(id)}`).join('\n'):'Tiada owner.'; return editMsg(chatId,msgId,isPhoto,`👑 ${b('SENARAI OWNER')} (${db.owners.length})\n${LS}\n\n<blockquote>${txt}</blockquote>`,{reply_markup:KB_MODERATOR}); }
  if (data==='mod_lantik_reseller')  { if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return; setSes(userId,{step:'lantik_username',backTo:'mod'}); return editMsg(chatId,msgId,isPhoto,`👤 ${b('LANTIK RESELLER')}\n${LS}\n\n<blockquote>📋 Langkah 1/3\nMasukkan ${b('@username')}:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='mod_upgrade_reseller') { if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return; setSes(userId,{step:'upgrade_reseller_input',backTo:'mod'}); return editMsg(chatId,msgId,isPhoto,`⬆️ ${b('NAIK TARAF RESELLER')}\n${LS}\n\n<blockquote>Masukkan Telegram ID reseller:</blockquote>`,{reply_markup:KB_CANCEL}); }
  if (data==='mod_delete_nombor')    { if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return; setSes(userId,{step:'owner_delete_input',backTo:'mod'}); return editMsg(chatId,msgId,isPhoto,`🗑 ${b('PADAM NOMBOR')}\n${LS}\n\n<blockquote>Masukkan nombor:\n${c('Contoh: 60123456789')}</blockquote>`,{reply_markup:KB_CANCEL}); }

  if (data==='guideline') return editMsg(chatId,msgId,isPhoto,`📢 ${b('KIZX BLASTER MANAGEMENT SYSTEM')}\n${LS}\n\n<blockquote>🧑‍💻 ${b('DEVELOPER')} - Full access\n💎 ${b('SUPER OWNER')} - Manage database & reseller\n👑 ${b('OWNER')} - Approve / padam / reseller\n🛡️ ${b('MODERATOR')} - Semak pending & senarai\n📦 ${b('RESELLER V5/G1')} - Akses database\n⛔ ${b('BLACKLIST')} - Auto disekat</blockquote>\n\n🔗 ${b('Group Rasmi:')}\n${CFG.GROUP_LINK_RASMI}\n\n${b(CFG.GROUP_NAME)} | DATABASE SYSTEM`,{reply_markup:{inline_keyboard:[[{text:sc('🏠 Back'),callback_data:'back_main'}]]}});

  if (data.startsWith('approve_')) {
    if (!isOwner(userId)) return;
    const rid=data.replace('approve_',''); const req=pending[rid];
    if (!req) { try{await bot.editMessageText(`⚠️ Request sudah diproses.`,{chat_id:chatId,message_id:msgId});}catch{} return; }
    const db=loadDB();
    if (req.type==='add') {
      if (db[req.ver].find(e=>e.nombor===req.nombor)) { delete pending[rid]; try{await bot.editMessageText(`⚠️ ${c(req.nombor)} sudah wujud! Auto-reject.`,{chat_id:chatId,message_id:msgId,parse_mode:'HTML'});}catch{} return; }
      db[req.ver].push({nombor:req.nombor,panel:req.panel,tarikh:new Date().toLocaleDateString('ms-MY'),approvedBy:S(userId),requesterId:req.rId,telegramId:req.rId});
      saveDB(db); delete pending[rid];
      const approverTag=cq.from.username?`@${cq.from.username}`:cq.from.first_name;
      const dbNotif=`✅ <b>DATABASE ${verLabel(req.ver)} – PENAMBAHAN BERJAYA</b>\n${LS}\n\n<blockquote>📱 <b>Nombor</b>     : ${c(req.nombor)}\n📦 <b>Versi</b>      : ${verLabel(req.ver)}\n👤 <b>Pelanggan</b>  : ${req.panel}\n🛡️ <b>Diluluskan</b> : ${approverTag}\n⏰ <b>Masa</b>       : ${masa()}</blockquote>\n\n<blockquote>✅ Permohonan database telah berjaya disahkan dan direkodkan ke dalam sistem rasmi KIZX.</blockquote>\n\n<b>KIZX BLASTER</b> | DATABASE PROTECTION`;
      await notifyOfficialGroups(dbNotif, req.resit);
      try{await bot.editMessageText(`✅ ${b('APPROVED!')}\n\n${c(req.nombor)} → ${b('DB '+verLabel(req.ver))}`,{chat_id:chatId,message_id:msgId,parse_mode:'HTML'});}catch{}
      return bot.sendMessage(req.rChat,dbNotif,{parse_mode:'HTML'});
    }
    if (req.type==='add2') {
      const idx=db[req.ver].findIndex(e=>e.nombor===req.nomborLama);
      if (idx===-1) { delete pending[rid]; try{await bot.editMessageText(`⚠️ Nombor lama tidak dijumpai.`,{chat_id:chatId,message_id:msgId});}catch{} return; }
      if (db[req.ver].find(e=>e.nombor===req.nomborBaru)) { delete pending[rid]; try{await bot.editMessageText(`⚠️ Nombor baru ${req.nomborBaru} sudah wujud! Auto-reject.`,{chat_id:chatId,message_id:msgId,parse_mode:'HTML'});}catch{} return; }
      // Nombor baru DITAMBAH sebagai rekod berasingan — nombor lama TIDAK dipadam/ditukar,
      // supaya kedua-dua nombor (lama & baru) terus boleh digunakan pada Bot Blaster.
      db[req.ver].push({nombor:req.nomborBaru,panel:req.panel,ulasan:req.ulasan,tarikh:new Date().toLocaleDateString('ms-MY'),approvedBy:S(userId),nomborRujukan:req.nomborLama});
      saveDB(db); delete pending[rid];
      const approverTag2=cq.from.username?`@${cq.from.username}`:cq.from.first_name;
      const notif2=`🔢 <b>NOMBOR 2 DILULUSKAN</b>\n${LS}\n\n<blockquote><b>Nombor Lama</b>: ${c(req.nomborLama)} (kekal aktif)\n<b>Nombor Baru</b>: ${c(req.nomborBaru)} (kini aktif)\n<b>DB</b>  : ${verLabel(req.ver)}\n<b>Oleh</b>: ${approverTag2}\n<b>Masa</b>: ${masa()}</blockquote>\n\n<blockquote>✅ Kedua-dua nombor (lama & baru) kini boleh terus digunakan pada Bot Blaster secara serentak.</blockquote>\n\n<b>KIZX BLASTER</b> | DATABASE SYSTEM`;
      await notifyOfficialGroups(notif2);
      try{await bot.editMessageText(`✅ ${b('APPROVED!')} - Nombor 2 ditambah (lama & baru aktif)\n\nLama: ${c(req.nomborLama)}\nBaru: ${c(req.nomborBaru)}`,{chat_id:chatId,message_id:msgId,parse_mode:'HTML'});}catch{}
      return bot.sendMessage(req.rChat,notif2,{parse_mode:'HTML'});
    }
  }

  if (data.startsWith('reject_')) {
    if (!isOwner(userId)) return;
    const rid=data.replace('reject_',''); const req=pending[rid];
    if (!req) { try{await bot.editMessageText(`⚠️ Request sudah diproses.`,{chat_id:chatId,message_id:msgId});}catch{} return; }
    delete pending[rid];
    try{await bot.editMessageText(`❌ ${b('REJECTED!')} oleh ${cq.from.first_name}`,{chat_id:chatId,message_id:msgId,parse_mode:'HTML'});}catch{}
    return bot.sendMessage(req.rChat,`❌ ${b('REQUEST DITOLAK!')}\n${LS}\n\n<blockquote>Request anda ditolak oleh admin.</blockquote>`,{parse_mode:'HTML'});
  }
}
bot.on('callback_query', handleCallbackAction);

bot.on('web_app_data', async (msg) => {
  try {
    const raw = msg.web_app_data.data;
    let action;
    try { action = JSON.parse(raw).action; } catch { action = raw; }
    const fakeCq = {
      id: 'webapp_' + Date.now(),
      message: { chat: { id: msg.chat.id }, message_id: msg.message_id, photo: null },
      from: msg.from,
      data: action,
    };
    await handleCallbackAction(fakeCq);
  } catch (e) {
    console.error('⚠️ web_app_data error:', e.message);
    bot.sendMessage(msg.chat.id, `❌ Ralat memproses WebApp: ${e.message}`).catch(()=>{});
  }
});


// ===============================================
//   MESSAGE HANDLER
// ===============================================
bot.on('message', async (msg) => {
  if (!msg.text&&!msg.photo&&!msg.document) return;
  if (msg.text&&msg.text.startsWith('/')) return;
  if (!isPrivate(msg)) return;
  const userId=msg.from.id, chatId=msg.chat.id;
  if (isBlacklisted(userId)) return bot.sendMessage(chatId,`⛔ Akun anda di-blacklist.`,{parse_mode:'HTML'});
  const sess=getSes(userId); if (!sess) return;
  const step=sess.step;

  if (step==='dev_add_owner_input') {
    if (!isDeveloper(userId)) return;
    const id=(msg.text||'').trim();
    if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL});
    clrSes(userId); const db=loadDB();
    if (isOwnerVvip(id)||isDeveloper(id)) return bot.sendMessage(chatId,`⚠️ ${c(id)} sudah Super Owner/Developer.`,{parse_mode:'HTML',reply_markup:KB_DEV});
    if (db.owners.includes(id)) return bot.sendMessage(chatId,`⚠️ ${c(id)} sudah Owner.`,{parse_mode:'HTML',reply_markup:KB_DEV});
    db.owners.push(id); saveDB(db);
    const aTag=msg.from&&msg.from.username?`@${msg.from.username}`:msg.from&&msg.from.first_name||'Admin';
    const notifOwner=`${LS}\n👑🎉 ${b('OWNER BARU DILANTIK!')}\n${LS}\n\n<blockquote>🆔 <b>ID</b>       : ${c(id)}\n👑 <b>Peranan</b>  : OWNER\n🧑‍💻 <b>Dilantik</b> : ${aTag}\n⏰ <b>Masa</b>     : ${masa()}</blockquote>\n\n<b>KIZX BLASTER</b> | ROLE MANAGEMENT`;
    await notifyOfficialGroups(notifOwner);
    for (const sid of notifyList()) { try { await bot.sendMessage(sid,notifOwner,{parse_mode:'HTML'}); } catch {} }
    return bot.sendMessage(chatId,`✅ ${b('OWNER DILANTIK!')}\n\nID: ${c(id)}`,{parse_mode:'HTML',reply_markup:KB_DEV});
  }
  if (step==='dev_rm_owner_input')  { if (!isDeveloper(userId)) return; const id=(msg.text||'').trim(); clrSes(userId); const db=loadDB(); const before=db.owners.length; db.owners=db.owners.filter(x=>x!==id); if (db.owners.length<before) { saveDB(db); return bot.sendMessage(chatId,`✅ ${b('OWNER DIBUANG!')}\n\nID: ${c(id)}`,{parse_mode:'HTML',reply_markup:KB_DEV}); } return bot.sendMessage(chatId,`⚠️ ID ${c(id)} tidak dijumpai.`,{parse_mode:'HTML',reply_markup:KB_DEV}); }
  if (step==='dev_add_vvip_input') {
    if (!isDeveloper(userId)) return;
    const id=(msg.text||'').trim();
    if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL});
    clrSes(userId); const db=loadDB();
    if (CFG.OWNER_VVIP_IDS.includes(id)||db.ownerVvip.includes(id)) return bot.sendMessage(chatId,`⚠️ ${c(id)} sudah Super Owner.`,{parse_mode:'HTML',reply_markup:KB_DEV});
    db.ownerVvip.push(id); saveDB(db);
    const aTagV=msg.from&&msg.from.username?`@${msg.from.username}`:msg.from&&msg.from.first_name||'Admin';
    const notifVvip=`${LS}\n💎🎉 ${b('SUPER OWNER BARU DILANTIK!')}\n${LS}\n\n<blockquote>🆔 <b>ID</b>       : ${c(id)}\n💎 <b>Peranan</b>  : SUPER OWNER\n🧑‍💻 <b>Dilantik</b> : ${aTagV}\n⏰ <b>Masa</b>     : ${masa()}</blockquote>\n\n<b>KIZX BLASTER</b> | ROLE MANAGEMENT`;
    await notifyOfficialGroups(notifVvip);
    for (const sid of notifyList()) { try { await bot.sendMessage(sid,notifVvip,{parse_mode:'HTML'}); } catch {} }
    return bot.sendMessage(chatId,`✅ ${b('SUPER OWNER DILANTIK!')}\n\nID: ${c(id)}`,{parse_mode:'HTML',reply_markup:KB_DEV});
  }
  if (step==='dev_rm_vvip_input')   { if (!isDeveloper(userId)) return; const id=(msg.text||'').trim(); clrSes(userId); const db=loadDB(); const before=db.ownerVvip.length; db.ownerVvip=db.ownerVvip.filter(x=>x!==id); if (db.ownerVvip.length<before) { saveDB(db); return bot.sendMessage(chatId,`✅ ${b('SUPER OWNER DIBUANG!')}`,{parse_mode:'HTML',reply_markup:KB_DEV}); } return bot.sendMessage(chatId,`⚠️ ID ${c(id)} tidak dijumpai. (Hanya dynamic boleh dibuang)`,{parse_mode:'HTML',reply_markup:KB_DEV}); }
  if (step==='dev_add_mod_input') {
    if (!isDeveloper(userId)&&!isOwnerVvip(userId)) return;
    const id=(msg.text||'').trim();
    if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL});
    clrSes(userId); const db=loadDB();
    if ((db.moderators||[]).includes(id)) return bot.sendMessage(chatId,`⚠️ ${c(id)} sudah Moderator.`,{parse_mode:'HTML',reply_markup:KB_DEV});
    db.moderators = db.moderators||[]; db.moderators.push(id); saveDB(db);
    const aTagM=msg.from&&msg.from.username?`@${msg.from.username}`:msg.from&&msg.from.first_name||'Admin';
    const notifMod=`${LS}\n🛡️🎉 ${b('MODERATOR BARU DILANTIK!')}\n${LS}\n\n<blockquote>🆔 <b>ID</b>       : ${c(id)}\n🛡️ <b>Peranan</b>  : MODERATOR\n👑 <b>Dilantik</b> : ${aTagM}\n⏰ <b>Masa</b>     : ${masa()}</blockquote>\n\n<b>KIZX BLASTER</b> | ROLE MANAGEMENT`;
    await notifyOfficialGroups(notifMod);
    for (const sid of notifyList()) { try { await bot.sendMessage(sid,notifMod,{parse_mode:'HTML'}); } catch {} }
    return bot.sendMessage(chatId,`✅ ${b('MODERATOR DILANTIK!')}\n\nID: ${c(id)}`,{parse_mode:'HTML',reply_markup:KB_DEV});
  }
  if (step==='dev_rm_mod_input') {
    if (!isDeveloper(userId)&&!isOwnerVvip(userId)) return;
    const id=(msg.text||'').trim(); clrSes(userId); const db=loadDB();
    const before=(db.moderators||[]).length; db.moderators=(db.moderators||[]).filter(x=>x!==id);
    if (db.moderators.length<before) { saveDB(db); return bot.sendMessage(chatId,`✅ ${b('MODERATOR DIBUANG!')}\n\nID: ${c(id)}`,{parse_mode:'HTML',reply_markup:KB_DEV}); }
    return bot.sendMessage(chatId,`⚠️ ID ${c(id)} tidak dijumpai dalam senarai Moderator.`,{parse_mode:'HTML',reply_markup:KB_DEV});
  }
  if (step==='mod_add_owner_input') {
    if (!isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return;
    const id=(msg.text||'').trim();
    if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL});
    clrSes(userId); const db=loadDB();
    if (isOwnerVvip(id)||isDeveloper(id)) return bot.sendMessage(chatId,`⚠️ ${c(id)} sudah Super Owner/Developer.`,{parse_mode:'HTML',reply_markup:KB_MODERATOR});
    if (db.owners.includes(id)) return bot.sendMessage(chatId,`⚠️ ${c(id)} sudah Owner.`,{parse_mode:'HTML',reply_markup:KB_MODERATOR});
    db.owners.push(id); saveDB(db);
    const aTagMO=msg.from&&msg.from.username?`@${msg.from.username}`:msg.from&&msg.from.first_name||'Moderator';
    const notifMO=`${LS}\n👑🎉 ${b('OWNER BARU DILANTIK!')}\n${LS}\n\n<blockquote>🆔 <b>ID</b>       : ${c(id)}\n👑 <b>Peranan</b>  : OWNER\n🛡️ <b>Dilantik</b> : ${aTagMO}\n⏰ <b>Masa</b>     : ${masa()}</blockquote>\n\n<b>KIZX BLASTER</b> | ROLE MANAGEMENT`;
    await notifyOfficialGroups(notifMO);
    for (const sid of notifyList()) { try { await bot.sendMessage(sid,notifMO,{parse_mode:'HTML'}); } catch {} }
    return bot.sendMessage(chatId,`✅ ${b('OWNER DILANTIK!')}\n\nID: ${c(id)}`,{parse_mode:'HTML',reply_markup:KB_MODERATOR});
  }
  if (step==='warn_target_id') {
    const id=(msg.text||'').trim();
    if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL});
    const db=loadDB();
    const kbBack = sess.panel==='dev'?KB_DEV:sess.panel==='mod'?KB_MODERATOR:sess.panel==='vvip'?KB_VVIP:KB_OWNER;
    if (sess.targetType==='owner') {
      if (!db.owners.includes(id)) return bot.sendMessage(chatId,`⚠️ ID ${c(id)} tidak dijumpai dalam senarai Owner.`,{parse_mode:'HTML',reply_markup:kbBack});
      setSes(userId,{...sess,step:'warn_target_reason',targetId:id});
      return bot.sendMessage(chatId,`⚠️ ${b('WARNING OWNER')}\n${LS}\n\n<blockquote>Masukkan sebab (reason) warning untuk ID ${c(id)}:</blockquote>`,{parse_mode:'HTML',reply_markup:KB_CANCEL});
    }
    const target=db.resellers.find(x=>x.userId===id);
    if (!target) return bot.sendMessage(chatId,`⚠️ ID ${c(id)} tidak dijumpai dalam senarai Reseller.`,{parse_mode:'HTML',reply_markup:kbBack});
    setSes(userId,{...sess,step:'warn_target_reason',targetId:id});
    return bot.sendMessage(chatId,`⚠️ ${b('WARNING RESELLER')}\n${LS}\n\n<blockquote>Masukkan sebab (reason) warning untuk ${b(target.username)}:</blockquote>`,{parse_mode:'HTML',reply_markup:KB_CANCEL});
  }
  if (step==='warn_target_reason') {
    const reason=(msg.text||'').trim();
    if (!reason) return bot.sendMessage(chatId,`⚠️ Sila masukkan sebab warning.`,{reply_markup:KB_CANCEL});
    const kbBack = sess.panel==='dev'?KB_DEV:sess.panel==='mod'?KB_MODERATOR:sess.panel==='vvip'?KB_VVIP:KB_OWNER;
    const db=loadDB();
    const maxWarn = 3;
    let warnCount, removed, displayName, roleLabel;

    if (sess.targetType==='owner') {
      if (!db.owners.includes(sess.targetId)) { clrSes(userId); return bot.sendMessage(chatId,`⚠️ Owner tidak dijumpai.`,{parse_mode:'HTML',reply_markup:kbBack}); }
      db.ownerWarnings[sess.targetId] = db.ownerWarnings[sess.targetId] || [];
      db.ownerWarnings[sess.targetId].push({ reason, by:S(userId), date:masa() });
      warnCount = db.ownerWarnings[sess.targetId].length;
      removed = false;
      if (warnCount >= maxWarn) {
        db.owners = db.owners.filter(x => x !== sess.targetId);
        delete db.ownerWarnings[sess.targetId];
        removed = true;
      }
      displayName = c(sess.targetId);
      roleLabel = 'OWNER';
    } else {
      const idx=db.resellers.findIndex(x=>x.userId===sess.targetId);
      if (idx<0) { clrSes(userId); return bot.sendMessage(chatId,`⚠️ Reseller tidak dijumpai.`,{parse_mode:'HTML',reply_markup:kbBack}); }
      const target=db.resellers[idx];
      target.warnings = target.warnings || [];
      target.warnings.push({ reason, by:S(userId), date:masa() });
      warnCount = target.warnings.length;
      removed = false;
      if (warnCount >= maxWarn) { db.resellers.splice(idx,1); removed = true; }
      displayName = b(target.username);
      roleLabel = 'RESELLER';
    }

    saveDB(db);
    clrSes(userId);
    const statusText = removed ? `⛔ ${roleLabel} DIBUANG (Max Warn)` : '✅ AKTIF';
    const notif = `⚠️ <b>AMARAN BERJAYA DIHANTAR</b>\n${LS}\n\n<blockquote>👤 <b>Sasaran</b>   : ${displayName} (${c(sess.targetId)})\n⚠️ <b>Jumlah Warn</b>: ${warnCount}/${maxWarn}\n📋 <b>Status</b>    : ${statusText}\n📝 <b>Reason</b>    : ${reason}</blockquote>\n\n<blockquote>${removed ? `⛔ ${roleLabel} telah mencapai had maksimum warning dan telah dibuang/dipecat secara automatik.` : '⚠️ Amaran telah berjaya direkodkan ke dalam sistem moderation KIZX BLASTER.'}</blockquote>\n\n<b>KIZX BLASTER</b> | DATABASE PROTECTION`;
    await notifyOfficialGroups(notif);
    return bot.sendMessage(chatId, notif, {parse_mode:'HTML',reply_markup:kbBack});
  }
  if (step==='unwarn_target_id') {
    if (sess.panel==='dev' && !isDeveloper(userId)) return;
    if (sess.panel==='vvip' && !isOwnerVvip(userId)) return;
    if (sess.panel==='mod' && !isModerator(userId)&&!isOwner(userId)&&!isDeveloper(userId)) return;
    const id=(msg.text||'').trim();
    if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL});
    const kbBack = sess.panel==='dev'?KB_DEV:sess.panel==='mod'?KB_MODERATOR:sess.panel==='vvip'?KB_VVIP:KB_OWNER;
    const db=loadDB();
    clrSes(userId);
    if (sess.targetType==='owner') {
      if (!db.owners.includes(id)) return bot.sendMessage(chatId,`⚠️ ID ${c(id)} tidak dijumpai dalam senarai Owner.`,{parse_mode:'HTML',reply_markup:kbBack});
      const jumlah = (db.ownerWarnings[id]||[]).length;
      if (!jumlah) return bot.sendMessage(chatId,`ℹ️ ID ${c(id)} tiada warning direkodkan.`,{parse_mode:'HTML',reply_markup:kbBack});
      delete db.ownerWarnings[id]; saveDB(db);
      return bot.sendMessage(chatId,`✅ ${b('WARNING DIRESET!')}\n${LS}\n\n<blockquote>👤 Owner: ${c(id)}\n⚠️ Warning lama: ${jumlah}\n📋 Status: 0/3 (bersih)</blockquote>`,{parse_mode:'HTML',reply_markup:kbBack});
    }
    const target=db.resellers.find(x=>x.userId===id);
    if (!target) return bot.sendMessage(chatId,`⚠️ ID ${c(id)} tidak dijumpai dalam senarai Reseller.`,{parse_mode:'HTML',reply_markup:kbBack});
    const jumlahR = (target.warnings||[]).length;
    if (!jumlahR) return bot.sendMessage(chatId,`ℹ️ ${b(target.username)} tiada warning direkodkan.`,{parse_mode:'HTML',reply_markup:kbBack});
    target.warnings=[]; saveDB(db);
    return bot.sendMessage(chatId,`✅ ${b('WARNING DIRESET!')}\n${LS}\n\n<blockquote>👤 Reseller: ${b(target.username)} (${c(id)})\n⚠️ Warning lama: ${jumlahR}\n📋 Status: 0/3 (bersih)</blockquote>`,{parse_mode:'HTML',reply_markup:kbBack});
  }
  if (step==='broadcast_all_input') {
    const kbBack = sess.panel==='dev'?KB_DEV:sess.panel==='vvip'?KB_VVIP:KB_OWNER;
    if (sess.panel==='dev' && !isDeveloper(userId)) return;
    if (sess.panel==='vvip' && !isOwnerVvip(userId)) return;
    if (sess.panel==='owner' && !isOwner(userId)) return;
    const txt=(msg.text||'').trim();
    if (!txt) return bot.sendMessage(chatId,`⚠️ Mesej kosong.`,{reply_markup:KB_CANCEL});
    clrSes(userId);
    const db=loadDB();
    const groups = [...new Set([...(db.config.groups||[]),...(db.config.groupId?[db.config.groupId]:[])])];
    const users = db.startedUsers || [];
    await bot.sendMessage(chatId,`⏳ Menghantar broadcast ke ${groups.length} group & ${users.length} user...`,{parse_mode:'HTML'});
    let gSent=0, gGagal=0, uSent=0, uGagal=0;
    for (const gid of groups) {
      try { await bot.sendMessage(gid, `📢 ${b('BROADCAST DARIPADA ADMIN')}\n${LS}\n\n<blockquote>${txt}</blockquote>\n\n${b(CFG.GROUP_NAME)}`, {parse_mode:'HTML'}); gSent++; }
      catch { gGagal++; }
    }
    for (const uid of users) {
      try { await bot.sendMessage(uid, `📣 ${b('BROADCAST')}\n${LS}\n\n<blockquote>${txt}</blockquote>`, {parse_mode:'HTML'}); uSent++; }
      catch { uGagal++; }
      await new Promise(r=>setTimeout(r,150)); // elak rate-limit Telegram
    }
    return bot.sendMessage(chatId,`✅ ${b('BROADCAST SELESAI!')}\n\n${LS}\n📢 ${b('Group')}: ${gSent} berjaya, ${gGagal} gagal\n📣 ${b('User')}: ${uSent} berjaya, ${uGagal} gagal`,{parse_mode:'HTML',reply_markup:kbBack});
  }
  if (step==='dev_bl_id_input')  { if (!isDeveloper(userId)) return; const id=(msg.text||'').trim(); if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL}); clrSes(userId); const db=loadDB(); if (!db.blacklistIds.includes(id)){db.blacklistIds.push(id);saveDB(db);} return bot.sendMessage(chatId,`⛔ ${b('BLACKLIST!')}\n\nID ${c(id)} di-blacklist.`,{parse_mode:'HTML',reply_markup:KB_DEV}); }
  if (step==='dev_bl_nom_input') { if (!isDeveloper(userId)) return; const nom=(msg.text||'').trim().replace(/\s+/g,''); clrSes(userId); const db=loadDB(); if (!db.blacklistNombor.includes(nom)){db.blacklistNombor.push(nom);saveDB(db);} return bot.sendMessage(chatId,`⛔ ${b('BLACKLIST!')}\n\nNombor ${c(nom)} di-blacklist.`,{parse_mode:'HTML',reply_markup:KB_DEV}); }
  if (step==='dev_bl_rm_input') { if (!isDeveloper(userId)) return; const val=(msg.text||'').trim().replace(/\s+/g,''); clrSes(userId); const db=loadDB(); const b4=db.blacklistIds.length+db.blacklistNombor.length; db.blacklistIds=db.blacklistIds.filter(x=>x!==val); db.blacklistNombor=db.blacklistNombor.filter(x=>x!==val); if ((db.blacklistIds.length+db.blacklistNombor.length)<b4){saveDB(db);return bot.sendMessage(chatId,`✅ ${b('BLACKLIST DIBUANG!')}\n\n${c(val)} dibuang.`,{parse_mode:'HTML',reply_markup:KB_DEV});} return bot.sendMessage(chatId,`⚠️ ${c(val)} tidak dijumpai dalam blacklist.`,{parse_mode:'HTML',reply_markup:KB_DEV}); }
  if (step==='vvip_add_owner_input') { if (!isOwnerVvip(userId)) return; const id=(msg.text||'').trim(); if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL}); clrSes(userId); const db=loadDB(); if (db.owners.includes(id)) return bot.sendMessage(chatId,`⚠️ ${c(id)} sudah Owner.`,{parse_mode:'HTML',reply_markup:KB_VVIP}); db.owners.push(id);saveDB(db); return bot.sendMessage(chatId,`✅ ${b('OWNER DITAMBAH!')}\n\nID: ${c(id)}`,{parse_mode:'HTML',reply_markup:KB_VVIP}); }
  if (step==='vvip_rm_owner_input')  { if (!isOwnerVvip(userId)) return; const id=(msg.text||'').trim(); clrSes(userId); const db=loadDB(); const before=db.owners.length; db.owners=db.owners.filter(x=>x!==id); if (db.owners.length<before){saveDB(db);return bot.sendMessage(chatId,`✅ ${b('OWNER DIBUANG!')}`,{parse_mode:'HTML',reply_markup:KB_VVIP});} return bot.sendMessage(chatId,`⚠️ ID ${c(id)} tidak dijumpai.`,{parse_mode:'HTML',reply_markup:KB_VVIP}); }
  if (step==='vvip_setgroup_input')  { if (!isSuperDeveloper(userId)) return; const gid=(msg.text||'').trim(); if (!/^-100\d+$/.test(gid)) return bot.sendMessage(chatId,`⚠️ Format salah! ${c('-100...')}`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); clrSes(userId); const db=loadDB(); db.config.groupId=gid; db.config.groupName=CFG.GROUP_NAME; saveDB(db); try{await bot.sendMessage(gid,`${LS}\n✅ ${b('GROUP DIAKTIFKAN')}\n${LS}\n\n${b(CFG.GROUP_NAME)} | DATABASE`,{parse_mode:'HTML'});}catch{} return bot.sendMessage(chatId,`✅ ${b('GROUP DITETAPKAN!')}\n\nID: ${c(gid)}`,{parse_mode:'HTML',reply_markup:KB_VVIP}); }
  if (step==='superdev_add_dev_input') {
    if (!isSuperDeveloper(userId)) return;
    const id=(msg.text||'').trim();
    if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL});
    clrSes(userId);
    const db=loadDB();
    if (CFG.DEVELOPER_IDS.includes(id) || db.developers.includes(id)) {
      return bot.sendMessage(chatId,`⚠️ ID ${c(id)} sudah menjadi Developer.`,{parse_mode:'HTML',reply_markup:KB_SUPER_DEV});
    }
    db.developers.push(id);
    saveDB(db);
    return bot.sendMessage(chatId,`✅ ${b('DEVELOPER DILANTIK!')}\n\nID: ${c(id)}`,{parse_mode:'HTML',reply_markup:KB_SUPER_DEV});
  }
  if (step==='superdev_rm_dev_input') {
    if (!isSuperDeveloper(userId)) return;
    const id=(msg.text||'').trim();
    clrSes(userId);
    const db=loadDB();
    if (CFG.SUPER_DEVELOPER_IDS.includes(id)) {
      return bot.sendMessage(chatId,`⛔ Tidak boleh buang Super Developer.`,{parse_mode:'HTML',reply_markup:KB_SUPER_DEV});
    }
    if (CFG.DEVELOPER_IDS.includes(id)) {
      return bot.sendMessage(chatId,`⚠️ ID ${c(id)} ialah Developer tetap (hardcoded) — tak boleh dibuang melalui bot.`,{parse_mode:'HTML',reply_markup:KB_SUPER_DEV});
    }
    if (!db.developers.includes(id)) {
      return bot.sendMessage(chatId,`⚠️ ID ${c(id)} tiada dalam senarai Developer dilantik.`,{parse_mode:'HTML',reply_markup:KB_SUPER_DEV});
    }
    db.developers = db.developers.filter(x=>x!==id);
    saveDB(db);
    return bot.sendMessage(chatId,`✅ Developer ${c(id)} telah dibuang.`,{parse_mode:'HTML',reply_markup:KB_SUPER_DEV});
  }
  if (step==='dev_domain_input') {
    if (!isSuperDeveloper(userId)) return;
    let input=(msg.text||'').trim();
    try { new URL(input); } catch {
      return bot.sendMessage(chatId,`⚠️ Format URL tidak sah.\nContoh: ${c('http://domain:port')} (WAJIB http, bukan https)`,{parse_mode:'HTML',reply_markup:KB_CANCEL});
    }
    let corrected = false;
    if (input.startsWith('https://')) { input = 'http://' + input.slice('https://'.length); corrected = true; }
    clrSes(userId);
    const clean = input.replace(/\/$/,'');
    CFG.saveDomainConfig(clean);
    return bot.sendMessage(chatId,`✅ ${b('DOMAIN DIKEMASKINI')}\n${LS}\n\n<blockquote>Domain baru:\n${c(clean)}${corrected?`\n\n⚠️ ${b('https:// auto-tukar ke http://')} — server API ni plain HTTP.`:''}\n\n⚠️ ${b('PENTING:')} Blaster V5 & G1 TIDAK auto-sync — kena update domain.json di kedua-dua Blaster secara manual juga.\n⏰ ${masa()}</blockquote>`,{parse_mode:'HTML',reply_markup:KB_DEV});
  }
  if (step==='bl_add_id')    { if (!isOwnerVvip(userId)) return; const id=(msg.text||'').trim(); if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL}); clrSes(userId); const db=loadDB(); if (!db.blacklistIds.includes(id)){db.blacklistIds.push(id);saveDB(db);} return bot.sendMessage(chatId,`⛔ ${b('BLACKLIST!')}\n\nID ${c(id)} di-blacklist.`,{parse_mode:'HTML',reply_markup:KB_VVIP}); }
  if (step==='bl_add_nombor') { if (!isOwnerVvip(userId)) return; const nom=(msg.text||'').trim().replace(/\s+/g,''); clrSes(userId); const db=loadDB(); if (!db.blacklistNombor.includes(nom)){db.blacklistNombor.push(nom);saveDB(db);} return bot.sendMessage(chatId,`⛔ ${b('BLACKLIST!')}\n\nNombor ${c(nom)} di-blacklist.`,{parse_mode:'HTML',reply_markup:KB_VVIP}); }
  if (step==='bl_rm_input')  { if (!isOwnerVvip(userId)) return; const val=(msg.text||'').trim(); clrSes(userId); const db=loadDB(); const b4=db.blacklistIds.length+db.blacklistNombor.length; db.blacklistIds=db.blacklistIds.filter(x=>x!==val); db.blacklistNombor=db.blacklistNombor.filter(x=>x!==val); if ((db.blacklistIds.length+db.blacklistNombor.length)<b4){saveDB(db);return bot.sendMessage(chatId,`✅ ${b('BLACKLIST DIBUANG!')}\n\n${c(val)} dibuang.`,{parse_mode:'HTML',reply_markup:KB_VVIP});} return bot.sendMessage(chatId,`⚠️ ${c(val)} tidak dijumpai.`,{parse_mode:'HTML',reply_markup:KB_VVIP}); }
  if (step==='upgrade_reseller_input') {
    if (!isOwner(userId)&&!isModerator(userId)) return;
    const id=(msg.text||'').trim(); if (!/^\d+$/.test(id)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL});
    const db=loadDB(); const r=db.resellers.find(x=>x.userId===id);
    const kbBackUpg = sess.backTo==='mod' ? KB_MODERATOR : KB_OWNER;
    if (!r){clrSes(userId);return bot.sendMessage(chatId,`❌ ID ${c(id)} tiada dalam senarai Reseller.`,{parse_mode:'HTML',reply_markup:kbBackUpg});}
    const newRole=r.role==='RESELLER V5'?'RESELLER G1':'RESELLER V5';
    setSes(userId,{step:'upgrade_confirm',targetId:id,oldRole:r.role,newRole,username:r.username,backTo:sess.backTo});
    return bot.sendMessage(chatId,`⬆️ ${b('SAHKAN NAIK TARAF')}\n${LS}\n\n<blockquote>Reseller: ${b(r.username)}\nID: ${c(id)}\nDari: ${b(r.role)}\nKepada: ${b(newRole)}</blockquote>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:sc(`✅ Ya, tukar ke ${newRole}`),callback_data:'confirm_upgrade'}],[{text:sc('❌ Batal'),callback_data:'cancel'}]]}});
  }

  if (step==='lantik_username') { if (!isOwner(userId)&&!isModerator(userId)) return; setSes(userId,{...sess,step:'lantik_nama',username:(msg.text||'').trim()}); return bot.sendMessage(chatId,`✅ Username diterima!\n\n📋 Langkah 2/4\nMasukkan ${b('nama penuh')} reseller:`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); }
  if (step==='lantik_nama')     { if (!isOwner(userId)&&!isModerator(userId)) return; setSes(userId,{...sess,step:'lantik_id',nama:(msg.text||'').trim()}); return bot.sendMessage(chatId,`✅ Nama diterima!\n\n📋 Langkah 3/4\nMasukkan ${b('Telegram ID')}:\n${c('Contoh: 123456789')}`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); }
  if (step==='lantik_id')       { if (!isOwner(userId)&&!isModerator(userId)) return; const rid=(msg.text||'').trim(); if (!/^\d+$/.test(rid)) return bot.sendMessage(chatId,`⚠️ ID mestilah nombor.`,{reply_markup:KB_CANCEL}); setSes(userId,{...sess,step:'lantik_role',resellerId:rid}); return bot.sendMessage(chatId,`✅ ID diterima!\n\n📋 Langkah 4/4\nPilih ${b('peranan')}:`,{parse_mode:'HTML',reply_markup:KB_ROLE}); }
  if (step==='owner_delete_input') {
    if (!isOwner(userId)&&!isModerator(userId)) return;
    const nombor=(msg.text||'').trim().replace(/\s+/g,''); clrSes(userId); const db=loadDB();
    let deleted=false,dv=''; for (const ver of ['v5','v6']){const idx=db[ver].findIndex(e=>e.nombor===nombor);if(idx!==-1){db[ver].splice(idx,1);deleted=true;dv=ver;break;}}
    const kbAfterDel = sess.backTo==='mod' ? KB_MODERATOR : KB_OWNER;
    if(deleted){saveDB(db);return bot.sendMessage(chatId,`🗑 ${b('NOMBOR DIPADAM!')}\n\n${c(nombor)} dari ${b('DB '+verLabel(dv))}.`,{parse_mode:'HTML',reply_markup:kbAfterDel});}
    return bot.sendMessage(chatId,`❌ ${b('TIDAK DIJUMPAI!')}\n\n${c(nombor)} tiada.`,{parse_mode:'HTML',reply_markup:kbAfterDel});
  }
  if (step==='semak_all_input') { const nombor=(msg.text||'').trim().replace(/\s+/g,''); if (!/^[0-9]{10,15}$/.test(nombor)) return bot.sendMessage(chatId,`⚠️ Format salah! ${c('60123456789')}`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); clrSes(userId); const db=loadDB(); const found=[]; for (const ver of ['v5','v6']){const e=db[ver].find(x=>x.nombor===nombor);if(e)found.push({ver,...e});} if(found.length){const rows=found.map(e=>`${b('DB '+verLabel(e.ver))}\nPanel: ${b(e.panel)}\nTarikh: ${e.tarikh||'-'}`).join('\n\n');return bot.sendMessage(chatId,`✅ ${b('DIJUMPAI')}\n${LS}\n\n<blockquote>Nombor: ${c(nombor)}\n\n${rows}</blockquote>`,{parse_mode:'HTML',reply_markup:kbMain(userId)});}return bot.sendMessage(chatId,`❌ ${b('TIDAK DIJUMPAI')}\n\n${c(nombor)} tiada.`,{parse_mode:'HTML',reply_markup:kbMain(userId)}); }
  if (step==='check_nombor') { const nombor=(msg.text||'').trim().replace(/\s+/g,''); if (!/^[0-9]{10,15}$/.test(nombor)) return bot.sendMessage(chatId,`⚠️ Format salah!`,{reply_markup:KB_CANCEL}); clrSes(userId); const db=loadDB(); const entry=db[sess.ver].find(e=>e.nombor===nombor); if(entry)return bot.sendMessage(chatId,`✅ ${b('DIJUMPAI')}\n${LS}\n\n<blockquote>Nombor: ${c(entry.nombor)}\nDB: ${b('DB '+verLabel(sess.ver))}\nPanel: ${b(entry.panel)}\nTarikh: ${entry.tarikh||'-'}</blockquote>`,{parse_mode:'HTML',reply_markup:kbDB(sess.ver,userId)});return bot.sendMessage(chatId,`❌ ${b('TIDAK DIJUMPAI')}\n\n${c(nombor)} tiada dalam ${b('DB '+verLabel(sess.ver))}.`,{parse_mode:'HTML',reply_markup:kbDB(sess.ver,userId)}); }
  if (step==='add_resit') { if (!msg.photo&&!msg.document) return bot.sendMessage(chatId,`⚠️ Sila hantar ${b('gambar resit')}.`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); const fileId=msg.photo?msg.photo[msg.photo.length-1].file_id:msg.document.file_id; setSes(userId,{...sess,step:'add_nombor',resit:fileId}); return bot.sendMessage(chatId,`✅ Resit diterima!\n\n📋 Langkah 2/3\nMasukkan ${b('nombor buyer')}:\n${c('Contoh: 60123456789')}`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); }
  if (step==='add_nombor') { const nombor=(msg.text||'').trim().replace(/\s+/g,''); if (!/^[0-9]{10,15}$/.test(nombor)) return bot.sendMessage(chatId,`⚠️ Format salah!`,{reply_markup:KB_CANCEL}); const db=loadDB(); if(db.blacklistNombor.includes(nombor))return bot.sendMessage(chatId,`⛔ ${b('NOMBOR BLACKLIST!')}`,{parse_mode:'HTML',reply_markup:kbDB(sess.ver,userId)}); const dup=db[sess.ver].find(e=>e.nombor===nombor); if(dup){clrSes(userId);return bot.sendMessage(chatId,`⚠️ ${b('NOMBOR SUDAH WUJUD!')}\n\n${c(nombor)}\nPanel: ${b(dup.panel)}`,{parse_mode:'HTML',reply_markup:kbDB(sess.ver,userId)});} setSes(userId,{...sess,step:'add_panel',nombor}); return bot.sendMessage(chatId,`✅ Nombor diterima!\n\n📋 Langkah 3/3\nMasukkan ${b('nama panel')}:\n${c('Contoh: KIZX STORE')}`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); }
  if (step==='add_panel') { const panel=(msg.text||'').trim(); if (!panel) return bot.sendMessage(chatId,'⚠️ Panel tidak boleh kosong.',{reply_markup:KB_CANCEL}); return submitAdd(chatId,userId,{...sess,panel}); }
  if (step==='add2_nombor_lama') { const nombor=(msg.text||'').trim().replace(/\s+/g,''); if (!/^[0-9]{10,15}$/.test(nombor)) return bot.sendMessage(chatId,`⚠️ Format salah!`,{reply_markup:KB_CANCEL}); const db=loadDB(); if(!db[sess.ver].find(e=>e.nombor===nombor))return bot.sendMessage(chatId,`❌ ${c(nombor)} tiada dalam DB ${verLabel(sess.ver)}.`,{parse_mode:'HTML',reply_markup:kbDB(sess.ver,userId)}); setSes(userId,{...sess,step:'add2_nombor_baru',nomborLama:nombor}); return bot.sendMessage(chatId,`✅ Nombor lama dijumpai!\n\n📋 Langkah 2/4\nMasukkan ${b('nombor baru')}:`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); }
  if (step==='add2_nombor_baru') { const nombor=(msg.text||'').trim().replace(/\s+/g,''); if (!/^[0-9]{10,15}$/.test(nombor)) return bot.sendMessage(chatId,`⚠️ Format salah!`,{reply_markup:KB_CANCEL}); const db=loadDB(); if(db[sess.ver].find(e=>e.nombor===nombor))return bot.sendMessage(chatId,`⚠️ Nombor ${c(nombor)} sudah wujud!`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); setSes(userId,{...sess,step:'add2_panel',nomborBaru:nombor}); return bot.sendMessage(chatId,`✅ Nombor baru diterima!\n\n📋 Langkah 3/4\nMasukkan ${b('nama panel')}:`,{parse_mode:'HTML',reply_markup:KB_CANCEL}); }
  if (step==='add2_panel')  { setSes(userId,{...sess,step:'add2_ulasan',panel:(msg.text||'').trim()}); return bot.sendMessage(chatId,`✅ Panel diterima!\n\n📋 Langkah 4/4\nMasukkan ${b('ulasan')} atau tekan Skip:`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:sc('⏭ Skip'),callback_data:'skip_ulasan2'}],[{text:sc('❌ Batal'),callback_data:'cancel'}]]}}); }
  if (step==='add2_ulasan') return submitAdd2(chatId,userId,{...sess,ulasan:(msg.text||'').trim()||'-'});

});

// ===============================================
//   SUBMIT HELPERS
// ===============================================
async function submitAdd(chatId, userId, sess) {
  clrSes(userId);
  const db = loadDB();
  if (db.blacklistNombor.includes(sess.nombor)) {
    return bot.sendMessage(chatId,`⛔ ${b('NOMBOR BLACKLIST!')}`,{parse_mode:'HTML'});
  }
  if (db[sess.ver].find(e=>e.nombor===sess.nombor)) {
    return bot.sendMessage(chatId,`⚠️ ${b('NOMBOR SUDAH WUJUD!')}`,{parse_mode:'HTML'});
  }
  const id=String(++reqCtr);
  pending[id]={type:'add',ver:sess.ver,nombor:sess.nombor,panel:sess.panel,resit:sess.resit,rId:userId,rChat:chatId};
  await bot.sendMessage(chatId,`⏳ ${b('REQUEST DIHANTAR!')}\n${LS}\n\n<blockquote>Nombor: ${c(sess.nombor)}\nPanel: ${b(sess.panel)}\nDB: ${b('DB '+verLabel(sess.ver))}</blockquote>\n\nMenunggu approval owner/dev/VVIP.`,{parse_mode:'HTML'});
  for (const sid of notifyList()) {
    try {
      await bot.sendMessage(sid,`📨 ${b('REQUEST TAMBAH NOMBOR')}\n${LS}\n\n<blockquote>DB: ${b('DB '+verLabel(sess.ver))}\nNombor: ${c(sess.nombor)}\nPanel: ${b(sess.panel)}\nDari: <a href="tg://user?id=${userId}">${userId}</a></blockquote>\n\nAPPROVE atau REJECT:`,{parse_mode:'HTML',reply_markup:kbApprove(id)});
      if (sess.resit) await bot.sendPhoto(sid,sess.resit,{caption:`📎 Resit - Request #${id}`,parse_mode:'HTML'});
    } catch(e){console.error(`Notify ${sid}:`,e.message);}
  }
}

async function submitAdd2(chatId, userId, sess) {
  clrSes(userId);
  const id=String(++reqCtr);
  pending[id]={type:'add2',ver:sess.ver,nomborLama:sess.nomborLama,nomborBaru:sess.nomborBaru,panel:sess.panel,ulasan:sess.ulasan||'-',rId:userId,rChat:chatId};
  await bot.sendMessage(chatId,`⏳ ${b('REQUEST DIHANTAR!')}\n${LS}\n\n<blockquote>Nombor Lama (kekal aktif): ${c(sess.nomborLama)}\nNombor Baru (akan ditambah): ${c(sess.nomborBaru)}\nPanel: ${b(sess.panel)}\nDB: ${b('DB '+verLabel(sess.ver))}</blockquote>\n\nMenunggu approval owner.`,{parse_mode:'HTML'});
  for (const sid of notifyList()) {
    try { await bot.sendMessage(sid,`📨 ${b('REQUEST TAMBAH NOMBOR 2')}\n${LS}\n\n<blockquote>DB: ${b('DB '+verLabel(sess.ver))}\nNombor Lama (kekal aktif): ${c(sess.nomborLama)}\nNombor Baru (akan ditambah): ${c(sess.nomborBaru)}\nPanel: ${b(sess.panel)}\nDari: <a href="tg://user?id=${userId}">${userId}</a></blockquote>\n\nAPPROVE atau REJECT:`,{parse_mode:'HTML',reply_markup:kbApprove(id)}); } catch(e){console.error(`Notify ${sid}:`,e.message);}
  }
}

// ===============================================
//   /setdomain — tukar domain API (Developer sahaja)
//   Contoh: /setdomain http://private.lynzzofficial.com:2066  (WAJIB http, server ni bukan HTTPS)
// ===============================================
bot.onText(/\/setdomain(?:\s+(\S+))?/, async (msg, match) => {
  if (!isSuperDeveloper(msg.from.id)) return bot.sendMessage(msg.chat.id, `⛔ Hanya Super Developer boleh tukar domain.`, { parse_mode: 'HTML' });
  let input = (match && match[1] || '').trim();
  if (!input) {
    const cur = CFG.getDomainConfig();
    return bot.sendMessage(msg.chat.id, `⚙️ ${b('DOMAIN API SEMASA')}\n${LS}\n\n<blockquote>${c(cur || '(belum ditetapkan)')}\n\nGuna: ${c('/setdomain http://domain:port')} (WAJIB http)</blockquote>`, { parse_mode: 'HTML' });
  }
  try { new URL(input); } catch {
    return bot.sendMessage(msg.chat.id, `⚠️ Format URL tidak sah.\nContoh: ${c('/setdomain http://private.lynzzofficial.com:2066')} (WAJIB http)`, { parse_mode: 'HTML' });
  }
  let corrected = false;
  if (input.startsWith('https://')) { input = 'http://' + input.slice('https://'.length); corrected = true; }
  const clean = input.replace(/\/$/, '');
  CFG.saveDomainConfig(clean);
  await bot.sendMessage(msg.chat.id, `✅ ${b('DOMAIN DIKEMASKINI')}\n${LS}\n\n<blockquote>Domain baru:\n${c(clean)}${corrected?`\n\n⚠️ ${b('https:// auto-tukar ke http://')} — server API ni plain HTTP.`:''}\n\n⚠️ ${b('PENTING:')} Blaster V5 & G1 TIDAK auto-sync — kena update domain.json di kedua-dua Blaster secara manual juga.\n⏰ ${masa()}</blockquote>`, { parse_mode: 'HTML' });
});

bot.on('error', err => console.error('Bot error:', err.message));
process.on('uncaughtException', err => console.error('Uncaught:', err.message));
process.on('unhandledRejection', reason => console.error('Rejection:', reason));

// ===============================================
//   API SEMAK NOMBOR — untuk Blaster di server LAIN
//   HANYA jawab ya/tak untuk SATU nombor yang ditanya.
//   TIDAK PERNAH dedah senarai penuh database.
// ===============================================
const apiServer = http.createServer((req, res) => {
  const url = new URL(req.url, `http://localhost:${CFG.API_PORT}`);

  if (req.method === 'GET' && url.pathname === '/webapp') {
    try {
      const html = fs.readFileSync(path.join(__dirname, 'webapp', 'index.html'), 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(html);
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      return res.end('WebApp file not found: ' + e.message);
    }
  }

  if (req.method === 'GET' && url.pathname === '/api/check-number') {
    if (url.searchParams.get('key') !== CFG.API_SECRET) {
      res.writeHead(403, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
    const nombor = (url.searchParams.get('number') || '').replace(/\D/g, '');
    if (!nombor) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Parameter "number" diperlukan' }));
    }
    try {
      const db = loadDB();
      const allowed = [...(db.v5 || []), ...(db.v6 || [])].some(e => String(e.nombor).trim() === nombor);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ allowed }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && url.pathname === '/api/add-number') {
    if (url.searchParams.get('key') !== CFG.API_SECRET) {
      res.writeHead(403, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
    let body = '';
    req.on('data', (chunk) => { body += chunk; if (body.length > 10000) req.destroy(); });
    req.on('end', () => {
      try {
        const data = JSON.parse(body || '{}');
        const ver = data.ver === 'v5' ? 'v5' : 'v6';
        const nombor = String(data.nombor || '').replace(/\D/g, '');
        const panel = String(data.panel || '-').trim() || '-';
        const addedBy = String(data.addedBy || '-');

        if (!/^[0-9]{9,15}$/.test(nombor)) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ ok: false, reason: 'Format nombor tidak sah.' }));
        }
        const db = loadDB();
        if (db.blacklistNombor.includes(nombor)) {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ ok: false, reason: `Nombor ${nombor} disenaraihitamkan.` }));
        }
        if (db[ver].find((e) => e.nombor === nombor)) {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ ok: false, reason: `Nombor ${nombor} sudah wujud dalam DB.` }));
        }
        db[ver].push({ nombor, panel, tarikh: new Date().toLocaleDateString('ms-MY'), approvedBy: 'BLASTER-API', addedVia: 'blaster-api', addedBy });
        saveDB(db);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ ok: true }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ ok: false, reason: e.message }));
      }
    });
    return;
  }

  if (req.method === 'GET' && url.pathname === '/ping') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    return res.end('OK');
  }
  res.writeHead(404);
  res.end();
});

apiServer.listen(CFG.API_PORT, '0.0.0.0', () => {
  console.log(`✅ API Semak Nombor aktif di port ${CFG.API_PORT} (hanya jawab ya/tak, tiada dump database).`);
});

console.log('✅ KIZX Management System v3.0 berjalan.');
console.log('💡 PENTING: Hanya jalankan SATU instance bot!');
