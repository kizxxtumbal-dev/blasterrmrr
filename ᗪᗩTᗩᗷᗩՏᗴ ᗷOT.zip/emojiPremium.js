// ============================================================
//  emojiPremium.js  –  Telegram Custom (Premium) Emoji Helper
//  Support Bot API 9.4: style + icon_custom_emoji_id on buttons
// ============================================================

const emojiIds = {
  "🍂": "5350600494203039686",
  "💻": "5927067268050587417",
  "🚀": "5350490470025816976",
  "🌸": "5352669672007296875",
  "🛍️": "5312361253610475399",
  "👑": "6235252066554484059",
  "⚡": "5224607267797606837",
  "🛍":  "5312361253610475399",
  "🛠️": "5350330761666915080",
  "🛠":  "5350330761666915080",
  "📊": "5884161133174067365",
  "📱": "5967591100532134862",
  "📁": "5433653135799228968",
  "📡": "4972388075003970512",
  "⌛": "5386367538735104399",
  "👨‍💻": "5418063924933173277",
  "🖥️": "5373330964372004748",
  "🖥":  "5373330964372004748",
  "🤝": "5357080225463149588",
  "🤖": "5350635725819768084",
  "🌟": "5458799228719472718",
  "🌐": "5447410659077661506",
  "👤": "5350837894225358832",
  "📅": "5413879192267805083",
  "💰": "6235459831302460476",
  "🔙": "5352759161945867747",
  "🛒": "5352718875152639926",
  "⏰": "5413704112220949842",
  "📦": "5854908544712707500",
  "💾": "5350681793638983859",
  "🕒": "5778605968208170641",
  "🎉": "6242319667168287353",
  "📋": "5197269100878907942",
  "📝": "5334882760735598374",
  "🚫": "5350496629008917458",
  "📨": "5967456680940671207",
  "💳": "5258204546391351475",
  "🧾": "5444856076954520455",
  "💵": "5255981634527704754",
  "⚠️": "5893290369629556374",
  "⚠":  "5893290369629556374",
  "💡": "5350734660391432462",
  "🎀": "5400319228895054886",
  "🆔": "5990171882500920057",
  "🔐": "5197288647275071607",
  "🔢": "6073395072953485376",
  "🪪": "5863838791038407008",
  "📜": "5811989245761426317",
  "💎": "5471952986970267163",
  "⚙️": "5350725709679584478",
  "⚙":  "5350725709679584478",
  "✅": "5350342542762209455",
  "💸": "5992246772611681940",
  "🛡️": "5350806480834553770",
  "🛡":  "5350806480834553770",
  "♻️": "6251145511428950009",
  "♻":  "6251145511428950009",
  "🌍": "5224450179368767019",
  "💿": "5215352343419167936",
  "🧩": "5927224403724078814",
  "⏩": "5893168654551355607",
  "❌": "5447644880824181073",
  "🔍": "5197291578305008600",
  "📩": "5361107795811471502",
  "💬": "5253106021545116605",
  "🥚": "5470113903448956707",
};

const namedEmoji = {
  "phone_order": "5967591100532134862",
  "phone_apps":  "5407025283456835913",
};

function wrapEmoji(emoji) {
  const id = emojiIds[emoji];
  if (!id) return emoji;
  return '<tg-emoji emoji-id="' + id + '">' + emoji + '</tg-emoji>';
}

/**
 * Ganti semua emoji dalam teks dengan versi premium.
 * IDEMPOTENT - aman dipanggil berkali-kali.
 */
function premiumEmoji(text) {
  if (!text || typeof text !== "string") return text;
  const saved = [];
  let safe = text.replace(/<tg-emoji[^>]*>[\s\S]*?<\/tg-emoji>/g, function(match) {
    saved.push(match);
    return "TGEMOJI_PLACEHOLDER_" + (saved.length - 1) + "_END";
  });
  const emojiRegex = /\p{Emoji_Presentation}(?:\uFE0F)?(?:\u200D\p{Emoji_Presentation}(?:\uFE0F)?)*|\p{Emoji}\uFE0F/gu;
  safe = safe.replace(emojiRegex, function(match) { return wrapEmoji(match); });
  return safe.replace(/TGEMOJI_PLACEHOLDER_(\d+)_END/g, function(_, i) {
    return saved[parseInt(i)];
  });
}

/**
 * Buat tg-emoji tag dari ID langsung.
 */
function tgEmoji(emojiId, fallback) {
  fallback = fallback || "⭐";
  return '<tg-emoji emoji-id="' + emojiId + '">' + fallback + '</tg-emoji>';
}

/**
 * Ambil emoji pertama dari teks tombol.
 * Digunakan untuk icon_custom_emoji_id.
 */
function getFirstEmoji(text) {
  const emojiRegex = /\p{Emoji_Presentation}(?:\uFE0F)?(?:\u200D\p{Emoji_Presentation}(?:\uFE0F)?)*|\p{Emoji}\uFE0F/gu;
  const match = text.match(emojiRegex);
  return match ? match[0] : null;
}

/**
 * Buat objek button Telegram dengan support Bot API 9.4:
 * - style  : "primary" (biru) | "success" (hijau) | "danger" (merah)
 * - icon_custom_emoji_id: otomatis dari emoji pertama di teks tombol
 *
 * @param {string} text - teks tombol (boleh ada emoji)
 * @param {string|null} callbackData
 * @param {object} extra - field tambahan: url, style, icon_custom_emoji_id, dll
 */
function buildButton(text, callbackData, extra) {
  extra = extra || {};
  const btn = { text };

  // Set callback_data atau url
  if (callbackData) btn.callback_data = callbackData;
  if (extra.url) btn.url = extra.url;

  // Style (Bot API 9.4)
  if (extra.style) btn.style = extra.style;

  // icon_custom_emoji_id (Bot API 9.4)
  // Jika tidak disediakan, coba ambil dari emoji pertama di teks
  if (extra.icon_custom_emoji_id) {
    btn.icon_custom_emoji_id = extra.icon_custom_emoji_id;
  } else {
    const firstEmoji = getFirstEmoji(text);
    if (firstEmoji && emojiIds[firstEmoji]) {
      btn.icon_custom_emoji_id = emojiIds[firstEmoji];
    }
  }

  return btn;
}

module.exports = { premiumEmoji, wrapEmoji, tgEmoji, buildButton, getFirstEmoji, emojiIds, namedEmoji };
