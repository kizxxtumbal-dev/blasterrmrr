// ===================================================
//   KIZX DATABASE BOT - CONFIG
//   Edit nilai di sini untuk konfigurasi bot
// ===================================================

module.exports = {
  TOKEN: "8758103538:AAEXv7SRIA0ghBYw4jPLrDF1ZY_buWJQOCc",

  // IDs hardcoded (tidak boleh ditukar melalui bot)
  SUPER_DEVELOPER_IDS: ["6946122020"],
  DEVELOPER_IDS:   ["6946122020", "8477166862"],
  OWNER_VVIP_IDS:  ["8383241545"],

  // Nama & Link
  BOT_NAME:        "KIZX DATABASE",
  GROUP_NAME:      "KIZX BLASTER",
  GROUP_LINK:      "https://t.me/+bXo7HCf7uPk4MGY1",
  GROUP_LINK_RASMI:"https://t.me/+-q3zGuCTi2ZhN2M1",

  // --- NOTIFIKASI (lantik reseller/owner/VVIP & database approved) -----
  // Bot MESTI jadi ahli kedua-dua group ni dulu. Untuk dapatkan ID numerik:
  // masuk group tu, hantar /id, salin nilai "Group ID" (contoh: -1001234567890).
  GROUP_ID_MAIN:   "-1004444772849",
  GROUP_ID_RASMI:  "-1003771596555",

  // --- API SEMAK NOMBOR (untuk Blaster di server LAIN) -----------------
  // Guna bila main bot & Blaster TIDAK sekongsi fail (server berasingan).
  // API ni HANYA jawab ya/tak untuk SATU nombor yang ditanya — tak pernah
  // dedah senarai penuh database (beza dengan sistem lama yang tak selamat).
  API_PORT:   process.env.SERVER_PORT || process.env.API_PORT || 3268,

  // Isi bila Cloudflare Tunnel/reverse proxy HTTPS dah siap (WAJIB https://, tak boleh http://)
  // Contoh: "https://private.lynzzofficial.com:2066/webapp"
  WEBAPP_URL: "https://private.lynzzofficial.com:2066/webapp",
  // TUKAR ni ke rentetan rawak panjang sendiri — JANGAN guna nilai contoh ni.
  API_SECRET: "7c4b5d80853b4d6f545bce6870352aadeac9772dcf814a897e40e8420e39bae5",
  // --- AUTO BACKUP BERJADUAL (hantar ke Telegram developer/owner) -----
  // Berapa jam sekali backup penuh (reseller, nombor V5/G1, owner, VVIP, developer)
  // dihantar sebagai fail ke semua developer/owner/VVIP. 0 = matikan.
  BACKUP_INTERVAL_HOURS: 6,
};

// --- /setdomain helper --- baca & simpan domain ke domain.json ---
const _fs   = require('fs');
const _path = require('path');
const _DOMAIN_FILE = _path.join(__dirname, 'domain.json');
module.exports.getDomainConfig = function () {
  try {
    const d = JSON.parse(_fs.readFileSync(_DOMAIN_FILE, 'utf8'));
    let url = (d.url || '').replace(/\/$/, '');
    if (url.startsWith('https://')) url = 'http://' + url.slice('https://'.length); // paksa http, server ni plain HTTP
    return url;
  } catch { return ''; }
};
module.exports.saveDomainConfig = function (url) {
  _fs.writeFileSync(_DOMAIN_FILE, JSON.stringify({ url, updatedAt: new Date().toISOString() }, null, 2));
};
